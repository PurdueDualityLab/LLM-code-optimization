package org.biojava.nbio.aaproperties;

import org.biojava.nbio.aaproperties.xml.AminoAcidCompositionTable;
import org.biojava.nbio.aaproperties.xml.ElementTable;
import org.biojava.nbio.aaproperties.xml.MyValidationEventHandler;
import org.biojava.nbio.core.sequence.ProteinSequence;
import org.biojava.nbio.core.sequence.compound.AminoAcidCompound;
import org.biojava.nbio.core.sequence.compound.AminoAcidCompoundSet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.Unmarshaller;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Map;

public class PeptidePropertiesImpl implements IPeptideProperties {
    private final static Logger logger = LoggerFactory.getLogger(PeptidePropertiesImpl.class);
    private static final AminoAcidCompoundSet AA_SET = new AminoAcidCompoundSet();
    private static final Map<Character, AminoAcidCompound> AA_CHAR_MAP = new HashMap<>();
    static {
        for (AminoAcidCompound aa : AA_SET.getAllCompounds()) {
            String shortName = aa.getShortName();
            if (shortName != null && shortName.length() == 1) {
                char c = shortName.charAt(0);
                AA_CHAR_MAP.put(Character.toUpperCase(c), aa);
            }
        }
    }

    
    private static final double[] AA_MW = new double[26];
    private static final double[] AA_HYDROPATHY = new double[26];
    private static final double[][] AA_DIPEPTIDE_INSTABILITY = new double[26][26];
    static {
        
        for (char c = 'A'; c <= 'Z'; c++) {
            AminoAcidCompound aa = AA_CHAR_MAP.get(c);
            int idx = c - 'A';
            if (aa != null) {
                Double mw = Constraints.aa2MolecularWeight.get(aa);
                AA_MW[idx] = mw == null ? 0.0 : mw;
                Double hyd = Constraints.aa2Hydrophathicity.get(aa);
                AA_HYDROPATHY[idx] = hyd == null ? 0.0 : hyd;
            } else {
                AA_MW[idx] = 0.0;
                AA_HYDROPATHY[idx] = 0.0;
            }
        }
        
        for (Map.Entry<String, Double> e : Constraints.diAA2Instability.entrySet()) {
            String k = e.getKey();
            if (k.length() == 2) {
                int i = k.charAt(0) - 'A';
                int j = k.charAt(1) - 'A';
                if (i >= 0 && i < 26 && j >= 0 && j < 26) {
                    AA_DIPEPTIDE_INSTABILITY[i][j] = e.getValue();
                }
            }
        }
    }

    private double getWaterMoleculeWeight() {
        final double hydrogenMW = 1.0079;
        final double hydroxideMW = 17.0073;
        return hydrogenMW + hydroxideMW;
    }

    private char[] getSequence(String sequence, boolean ignoreCase) {
        if (ignoreCase) {
            return sequence.toUpperCase().toCharArray();
        } else {
            return sequence.toCharArray();
        }
    }

    private AminoAcidCompound getCompoundForChar(char aa) {
        return AA_CHAR_MAP.get(aa);
    }

    @Override
    public double getMolecularWeight(ProteinSequence sequence) {
        double value = 0.0;
        char[] seq = getSequence(sequence.toString(), true);
        for (int i = 0; i < seq.length; i++) {
            char c = seq[i];
            if (c >= 'A' && c <= 'Z') {
                value += AA_MW[c - 'A'];
            }
        }
        if (value == 0)
            return value;
        else
            return value + getWaterMoleculeWeight();
    }

    @Override
    public double getMolecularWeight(ProteinSequence sequence, File aminoAcidCompositionFile) throws JAXBException, FileNotFoundException {
        File elementMassFile = new File("./src/main/resources/ElementMass.xml");
        if (!elementMassFile.exists()) {
            throw new FileNotFoundException("Cannot locate ElementMass.xml. " +
                    "Please use getMolecularWeight(ProteinSequence, File, File) to specify ElementMass.xml location.");
        }
        return getMolecularWeightBasedOnXML(sequence, obtainAminoAcidCompositionTable(elementMassFile, aminoAcidCompositionFile));
    }

    @Override
    public double getMolecularWeight(ProteinSequence sequence, File elementMassFile, File aminoAcidCompositionFile) throws JAXBException, FileNotFoundException {
        return getMolecularWeightBasedOnXML(sequence, obtainAminoAcidCompositionTable(elementMassFile, aminoAcidCompositionFile));
    }

    @Override
    public double getMolecularWeightBasedOnXML(ProteinSequence sequence, AminoAcidCompositionTable aminoAcidCompositionTable) {
        double value = 0.0;
        char[] seq = sequence.toString().toCharArray();
        for (int i = 0; i < seq.length; i++) {
            Double w = aminoAcidCompositionTable.getMolecularWeight(seq[i]);
            if (w != null) value += w;
        }
        if (value == 0.0)
            return value;
        else
            return value + getWaterMoleculeWeight();
    }

    @Override
    public AminoAcidCompositionTable obtainAminoAcidCompositionTable(File aminoAcidCompositionFile) throws JAXBException, FileNotFoundException {
        File elementMassFile = new File("./src/main/resources/ElementMass.xml");
        if (!elementMassFile.exists()) {
            throw new FileNotFoundException("Cannot locate ElementMass.xml. " +
                    "Please use getMolecularWeight(ProteinSequence, File, File) to specify ElementMass.xml location.");
        }
        return obtainAminoAcidCompositionTable(elementMassFile, aminoAcidCompositionFile);
    }

    @Override
    public AminoAcidCompositionTable obtainAminoAcidCompositionTable(File elementMassFile, File aminoAcidCompositionFile) throws JAXBException, FileNotFoundException {
        ElementTable iTable = new ElementTable();
        JAXBContext jc = JAXBContext.newInstance(iTable.getClass());
        Unmarshaller u = jc.createUnmarshaller();
        u.setEventHandler(new MyValidationEventHandler());
        iTable = (ElementTable) u.unmarshal(new FileInputStream(elementMassFile));
        iTable.populateMaps();
        AminoAcidCompositionTable aTable = new AminoAcidCompositionTable();
        JAXBContext jc2 = JAXBContext.newInstance(aTable.getClass());
        Unmarshaller u2 = jc2.createUnmarshaller();
        u2.setEventHandler(new MyValidationEventHandler());
        aTable = (AminoAcidCompositionTable) u2.unmarshal(new FileInputStream(aminoAcidCompositionFile));
        aTable.computeMolecularWeight(iTable);
        return aTable;
    }

    
    @Override
    public double getExtinctionCoefficient(ProteinSequence sequence, boolean assumeCysReduced) {
        Map<AminoAcidCompound, Integer> extinctAA2Count = this.getExtinctAACount(sequence);
        double eProt;
        if(!assumeCysReduced){
            eProt = extinctAA2Count.get(getCompoundForChar('Y')) *
                Constraints.aa2ExtinctionCoefficient.get(getCompoundForChar('Y')) +
                extinctAA2Count.get(getCompoundForChar('W')) *
                Constraints.aa2ExtinctionCoefficient.get(getCompoundForChar('W')) +
                extinctAA2Count.get(getCompoundForChar('C')) *
                Constraints.aa2ExtinctionCoefficient.get(getCompoundForChar('C'));
        }else
            eProt = extinctAA2Count.get(getCompoundForChar('Y')) *
                Constraints.aa2ExtinctionCoefficient.get(getCompoundForChar('Y')) +
                extinctAA2Count.get(getCompoundForChar('W')) *
                Constraints.aa2ExtinctionCoefficient.get(getCompoundForChar('W'));
        return eProt;
    }

    
    private Map<AminoAcidCompound, Integer> getExtinctAACount(ProteinSequence sequence){
        int numW = 0, smallW = 0, numY = 0, smallY = 0;
        double numC = 0, smallC = 0;
        for (char aa : sequence.getSequenceAsString().toCharArray()) {
            switch(aa){
            case 'W': numW++; break;
            case 'w': smallW++; break;
            case 'C': numC += 0.5; break;
            case 'c': smallC += 0.5; break;
            case 'Y': numY++; break;
            case 'y': smallY++; break;
            }
        }
        Map<AminoAcidCompound, Integer> extinctAA2Count = new HashMap<>();
        extinctAA2Count.put(getCompoundForChar('W'), numW + smallW);
        extinctAA2Count.put(getCompoundForChar('C'), (int) (numC + smallC));
        extinctAA2Count.put(getCompoundForChar('Y'), numY + smallY);
        return extinctAA2Count;
    }

    @Override
    public double getAbsorbance(ProteinSequence sequence, boolean assumeCysReduced) {
        double mw = this.getMolecularWeight(sequence);
        double eProt = this.getExtinctionCoefficient(sequence, assumeCysReduced);
        if (mw == 0.0) {
            logger.warn("Molecular weight is 0.0, can't divide by 0: setting absorbance to 0.0");
            return 0.0;
        }
        return eProt / mw;
    }

    @Override
    public double getInstabilityIndex(ProteinSequence sequence) {
        String s = sequence.getSequenceAsString().toUpperCase();
        char[] seq = s.toCharArray();
        double sum = 0.0;
        int n = s.length();
        for (int i = 0; i < n - 1; i++) {
            char c1 = seq[i];
            char c2 = seq[i + 1];
            if (c1 >= 'A' && c1 <= 'Z' && c2 >= 'A' && c2 <= 'Z') {
                sum += AA_DIPEPTIDE_INSTABILITY[c1 - 'A'][c2 - 'A'];
            }
        }
        int denominator = n - Utils.getNumberOfInvalidChar(s, null, true);
        if (denominator == 0) {
            logger.warn("Valid length of sequence is 0, can't divide by 0 to calculate instability index: setting instability index value to 0.0");
            return 0.0;
        }
        return sum * 10.0 / denominator;
    }

    @Override
    public double getApliphaticIndex(ProteinSequence sequence) {
        Map<AminoAcidCompound, Double> aa2Composition = getAAComposition(sequence);
        final double a = 2.9;
        final double b = 3.9;
        double xAla = aa2Composition.get(getCompoundForChar('A'));
        double xVal = aa2Composition.get(getCompoundForChar('V'));
        double xIle = aa2Composition.get(getCompoundForChar('I'));
        double xLeu = aa2Composition.get(getCompoundForChar('L'));
        return (xAla + (a * xVal) + (b * (xIle + xLeu))) * 100;
    }

    @Override
    public double getAvgHydropathy(ProteinSequence sequence) {
        int validLength = 0;
        double total = 0.0;
        char[] seq = this.getSequence(sequence.toString(), true);
        for (char c : seq) {
            if (c >= 'A' && c <= 'Z') {
                total += AA_HYDROPATHY[c - 'A'];
                validLength++;
            }
        }
        if (validLength == 0) {
            logger.warn("Valid length of sequence is 0, can't divide by 0 to calculate average hydropathy: setting average hydropathy to 0");
            return 0.0;
        }
        return total / validLength;
    }

    @Override
    public double getIsoelectricPoint(ProteinSequence sequence, boolean useExpasyValues) {
        if (useExpasyValues) {
            return this.getIsoelectricPointExpasy(sequence.toString().toUpperCase());
        } else {
            return this.getIsoelectricPointInnovagen(sequence);
        }
    }

    @Override
    public double getIsoelectricPoint(ProteinSequence sequence) {
        return getIsoelectricPoint(sequence, true);
    }

    private final double[][] cPk = {
            {3.55, 7.59, 0.0},
            {3.55, 7.50, 0.0},
            {3.55, 7.50, 9.00},
            {3.55, 7.50, 4.05},
            {3.55, 7.70, 4.45},
            {3.55, 7.50, 0},
            {3.55, 7.50, 0},
            {3.55, 7.50, 5.98},
            {3.55, 7.50, 0.0},
            {0.0, 0.0, 0.0},
            {3.55, 7.50, 10.00},
            {3.55, 7.50, 0.0},
            {3.55, 7.00, 0.0},
            {3.55, 7.50, 0.0},
            {0.00, 0.00, 0.0},
            {3.55, 8.36, 0.0},
            {3.55, 7.50, 0.0},
            {3.55, 7.50, 12.0},
            {3.55, 6.93, 0.0},
            {3.55, 6.82, 0.0},
            {0.00, 0.00, 0.0},
            {3.55, 7.44, 0.0},
            {3.55, 7.50, 0.0},
            {3.55, 7.50, 0.0},
            {3.55, 7.50, 10.00},
            {3.55, 7.50, 0.0}
    };
    private final double PH_MIN = 0.0;
    private final double PH_MAX = 14.0;
    private final double MAXLOOP = 2000.0;
    private final double EPSI = 0.0001;

    private double exp10(double pka) {
        return Math.pow(10, pka);
    }

    private double getIsoelectricPointExpasy(String sequence) {
        int[] comp = new int[26];
        for (int i = 0; i < sequence.length(); i++) {
            int index = sequence.charAt(i) - 'A';
            if (index < 0 || index >= 26) continue;
            comp[index]++;
        }
        int nTermResidue = -1;
        int index = 0;
        while ((nTermResidue < 0 || nTermResidue >= 26) && index < 25) {
            nTermResidue = sequence.charAt(index++) - 'A';
        }
        int cTermResidue = -1;
        index = 1;
        while ((cTermResidue < 0 || cTermResidue >= 26) && index < 25) {
            cTermResidue = sequence.charAt(sequence.length() - index++) - 'A';
        }
        double phMin = PH_MIN;
        double phMax = PH_MAX;
        double phMid = 0.0;
        double charge = 1.0;
        for (int i = 0; i < MAXLOOP && (phMax - phMin) > EPSI; i++) {
            phMid = phMin + (phMax - phMin) / 2.0;
            charge = getNetChargeExpasy(comp, nTermResidue, cTermResidue, phMid);
            if (charge > 0.0) phMin = phMid;
            else phMax = phMid;
        }
        return phMid;
    }

    private double getIsoelectricPointInnovagen(ProteinSequence sequence) {
        double currentPH = 7.0;
        double changeSize = 7.0;
        String sequenceString = sequence.toString();
        char nTerminalChar = sequenceString.charAt(0);
        char cTerminalChar = sequenceString.charAt(sequenceString.length() - 1);
        Map<AminoAcidCompound, Integer> chargedAA2Count = this.getChargedAACount(sequence);
        double margin;
        final double difference = 0.0001;
        while (true) {
            margin = this.getNetChargeInnovagen(chargedAA2Count, currentPH, nTerminalChar, cTerminalChar);
            if (margin <= difference && margin >= -difference) break;
            changeSize /= 2.0;
            if (margin > 0) {
                currentPH += changeSize;
            } else {
                currentPH -= changeSize;
            }
        }
        return currentPH;
    }

    @Override
    public double getNetCharge(ProteinSequence sequence) {
        return getNetCharge(sequence, true);
    }

    @Override
    public double getNetCharge(ProteinSequence sequence, boolean useExpasyValues) {
        return getNetCharge(sequence, useExpasyValues, 7.0);
    }

    @Override
    public double getNetCharge(ProteinSequence sequence, boolean useExpasyValues, double pHPoint) {
        if (useExpasyValues) {
            return getNetChargeExpasy(sequence.toString().toUpperCase(), pHPoint);
        } else {
            return getNetChargeInnovagen(sequence, pHPoint);
        }
    }

    private double getNetChargeExpasy(String sequence, double pHPoint) {
        int[] comp = new int[26];
        for (int i = 0; i < sequence.length(); i++) {
            int index = sequence.charAt(i) - 'A';
            if (index < 0 || index >= 26) continue;
            comp[index]++;
        }
        int nTermResidue = sequence.charAt(0) - 'A';
        int cTermResidue = sequence.charAt(sequence.length() - 1) - 'A';
        return getNetChargeExpasy(comp, nTermResidue, cTermResidue, pHPoint);
    }

    private double getNetChargeExpasy(int[] comp, int nTermResidue, int cTermResidue, double ph) {
        double cter = 0.0;
        if (cTermResidue >= 0 && cTermResidue < 26)
            cter = exp10(-cPk[cTermResidue][0]) / (exp10(-cPk[cTermResidue][0]) + exp10(-ph));
        double nter = 0.0;
        if (nTermResidue >= 0 && nTermResidue < 26)
            nter = exp10(-ph) / (exp10(-cPk[nTermResidue][1]) + exp10(-ph));
        double carg = comp['R' - 'A'] * exp10(-ph) / (exp10(-cPk['R' - 'A'][2]) + exp10(-ph));
        double chis = comp['H' - 'A'] * exp10(-ph) / (exp10(-cPk['H' - 'A'][2]) + exp10(-ph));
        double clys = comp['K' - 'A'] * exp10(-ph) / (exp10(-cPk['K' - 'A'][2]) + exp10(-ph));
        double casp = comp['D' - 'A'] * exp10(-cPk['D' - 'A'][2]) / (exp10(-cPk['D' - 'A'][2]) + exp10(-ph));
        double cglu = comp['E' - 'A'] * exp10(-cPk['E' - 'A'][2]) / (exp10(-cPk['E' - 'A'][2]) + exp10(-ph));
        double ccys = comp['C' - 'A'] * exp10(-cPk['C' - 'A'][2]) / (exp10(-cPk['C' - 'A'][2]) + exp10(-ph));
        double ctyr = comp['Y' - 'A'] * exp10(-cPk['Y' - 'A'][2]) / (exp10(-cPk['Y' - 'A'][2]) + exp10(-ph));
        return (carg + clys + chis + nter) - (casp + cglu + ctyr + ccys + cter);
    }

    private double getNetChargeInnovagen(ProteinSequence sequence, double pHPoint) {
        Map<AminoAcidCompound, Integer> chargedAA2Count = this.getChargedAACount(sequence);
        String sequenceString = sequence.getSequenceAsString();
        return getNetChargeInnovagen(chargedAA2Count, pHPoint, sequenceString.charAt(0), sequenceString.charAt(sequenceString.length() - 1));
    }

    private double getNetChargeInnovagen(Map<AminoAcidCompound, Integer> chargedAA2Count, double ph, char nTerminalChar, char cTerminalChar) {
        double nTerminalCharge = 0.0;
        AminoAcidCompound nTermCompound = getCompoundForChar(nTerminalChar);
        if (nTermCompound != null && Constraints.aa2NTerminalPka.containsKey(nTermCompound)) {
            nTerminalCharge = this.getPosCharge(Constraints.aa2NTerminalPka.get(nTermCompound), ph);
        }
        double cTerminalCharge = 0.0;
        AminoAcidCompound cTermCompound = getCompoundForChar(cTerminalChar);
        if (cTermCompound != null && Constraints.aa2CTerminalPka.containsKey(cTermCompound)) {
            cTerminalCharge = this.getNegCharge(Constraints.aa2CTerminalPka.get(cTermCompound), ph);
        }
        double kCharge = chargedAA2Count.get(getCompoundForChar('K')) * this.getPosCharge(Constraints.aa2PKa.get(getCompoundForChar('K')), ph);
        double rCharge = chargedAA2Count.get(getCompoundForChar('R')) * this.getPosCharge(Constraints.aa2PKa.get(getCompoundForChar('R')), ph);
        double hCharge = chargedAA2Count.get(getCompoundForChar('H')) * this.getPosCharge(Constraints.aa2PKa.get(getCompoundForChar('H')), ph);
        double dCharge = chargedAA2Count.get(getCompoundForChar('D')) * this.getNegCharge(Constraints.aa2PKa.get(getCompoundForChar('D')), ph);
        double eCharge = chargedAA2Count.get(getCompoundForChar('E')) * this.getNegCharge(Constraints.aa2PKa.get(getCompoundForChar('E')), ph);
        double cCharge = chargedAA2Count.get(getCompoundForChar('C')) * this.getNegCharge(Constraints.aa2PKa.get(getCompoundForChar('C')), ph);
        double yCharge = chargedAA2Count.get(getCompoundForChar('Y')) * this.getNegCharge(Constraints.aa2PKa.get(getCompoundForChar('Y')), ph);
        return (nTerminalCharge + kCharge + rCharge + hCharge) - (dCharge + eCharge + cCharge + yCharge + cTerminalCharge);
    }

    private double getPosCharge(double pka, double ph) {
        return Math.pow(10, pka) / (Math.pow(10, pka) + Math.pow(10, ph));
    }

    private double getNegCharge(double pka, double ph) {
        return Math.pow(10, ph) / (Math.pow(10, pka) + Math.pow(10, ph));
    }

    private Map<AminoAcidCompound, Integer> getChargedAACount(ProteinSequence sequence) {
        int numK = 0, numR = 0, numH = 0, numD = 0, numE = 0, numC = 0, numY = 0;
        char[] seq = this.getSequence(sequence.getSequenceAsString(), true);
        for (char aa : seq) {
            switch (aa) {
                case 'K': numK++; break;
                case 'R': numR++; break;
                case 'H': numH++; break;
                case 'D': numD++; break;
                case 'E': numE++; break;
                case 'C': numC++; break;
                case 'Y': numY++; break;
            }
        }
        Map<AminoAcidCompound, Integer> chargedAA2Count = new HashMap<>();
        chargedAA2Count.put(getCompoundForChar('K'), numK);
        chargedAA2Count.put(getCompoundForChar('R'), numR);
        chargedAA2Count.put(getCompoundForChar('H'), numH);
        chargedAA2Count.put(getCompoundForChar('D'), numD);
        chargedAA2Count.put(getCompoundForChar('E'), numE);
        chargedAA2Count.put(getCompoundForChar('C'), numC);
        chargedAA2Count.put(getCompoundForChar('Y'), numY);
        return chargedAA2Count;
    }

    @Override
    public double getEnrichment(ProteinSequence sequence, AminoAcidCompound aminoAcidCode) {
        double counter = 0.0;
        char[] seq = this.getSequence(sequence.getSequenceAsString(), true);
        String code = aminoAcidCode.getShortName();
        if (code != null && code.length() == 1) {
            char target = code.charAt(0);
            for (char aa : seq) {
                if (aa == target) {
                    counter++;
                }
            }
        }
        return counter / sequence.getLength();
    }

    @Override
    public Map<AminoAcidCompound, Double> getAAComposition(ProteinSequence sequence) {
        int validLength = 0;
        Map<AminoAcidCompound, Double> aa2Composition = new HashMap<>();
        
        char[] seq = this.getSequence(sequence.toString(), true);
        for (char aa : seq) {
            if (PeptideProperties.standardAASet.contains(aa)) {
                AminoAcidCompound compound = getCompoundForChar(aa);
                if (compound != null) {
                    aa2Composition.put(compound, aa2Composition.getOrDefault(compound, 0.0) + 1.0);
                    validLength++;
                }
            }
        }
        
        if (validLength > 0) {
            for (Map.Entry<AminoAcidCompound, Double> entry : aa2Composition.entrySet()) {
                aa2Composition.put(entry.getKey(), entry.getValue() / validLength);
            }
            
            for (AminoAcidCompound aa : AA_SET.getAllCompounds()) {
                aa2Composition.putIfAbsent(aa, 0.0);
            }
        } else {
            for (AminoAcidCompound aa : AA_SET.getAllCompounds()) {
                aa2Composition.put(aa, 0.0);
            }
        }
        return aa2Composition;
    }

    @Override
    public double getAromaticity(ProteinSequence sequence) {
        int validLength = sequence.getSequenceAsString().length();
        if (validLength == 0) {
            logger.warn("Valid length of sequence is 0, can't divide by 0 to calculate aromaticity: setting aromaticity to 0");
            return 0.0;
        }
        int totalF = 0, totalY = 0, totalW = 0;
        char[] seq = this.getSequence(sequence.toString(), true);
        for (char aa : seq) {
            switch (aa) {
                case 'F': totalF++; break;
                case 'Y': totalY++; break;
                case 'W': totalW++; break;
            }
        }
        return (totalF + totalY + totalW) / (double) (validLength);
    }
}
