package org.biojava.nbio.aaproperties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashSet;
import java.util.Set;
import java.util.stream.IntStream;

public class Utils {

    private final static Logger logger = LoggerFactory.getLogger(Utils.class);

    private static final double[] POWERS_OF_TEN = {
        1d, 10d, 100d, 1000d, 10000d, 100000d, 1000000d, 10000000d, 100000000d, 1000000000d,
        10000000000d, 100000000000d, 1000000000000d, 10000000000000d, 100000000000000d, 1000000000000000d
    };
    private static final int PARALLEL_THRESHOLD = 100_000;

    private static Set<Character> ensureHashSet(Set<Character> cSet) {
        if (cSet == null) return PeptideProperties.standardAASet;
        
        if (cSet instanceof HashSet) return cSet;
        
        return new HashSet<>(cSet);
    }

    public final static double roundToDecimals(double d, int c) {
        if (c < 0) return d;
        double p = (c < POWERS_OF_TEN.length) ? POWERS_OF_TEN[c] : Math.pow(10, c);
        return Math.round(d * p) / p;
    }

    public final static boolean doesSequenceContainInvalidChar(String sequence, Set<Character> cSet) {
        if (sequence == null) return false;
        Set<Character> setToUse = ensureHashSet(cSet);
        int len = sequence.length();
        for (int i = 0; i < len; i++) {
            if (!setToUse.contains(sequence.charAt(i))) return true;
        }
        return false;
    }

    public final static int getNumberOfInvalidChar(String sequence, Set<Character> cSet, boolean ignoreCase) {
        if (sequence == null) return 0;
        Set<Character> characterSet = ensureHashSet(cSet);
        int len = sequence.length();
        if (len > PARALLEL_THRESHOLD) {
            
            return (int) IntStream.range(0, len).parallel().map(i -> {
                char c = sequence.charAt(i);
                if (ignoreCase) c = Character.toUpperCase(c);
                return characterSet.contains(c) ? 0 : 1;
            }).sum();
        } else {
            int count = 0;
            for (int i = 0; i < len; i++) {
                char c = sequence.charAt(i);
                if (ignoreCase) c = Character.toUpperCase(c);
                if (!characterSet.contains(c)) count++;
            }
            return count;
        }
    }

    public final static String cleanSequence(String sequence, Set<Character> cSet) {
        if (sequence == null) return null;
        Set<Character> setToUse = ensureHashSet(cSet);
        int len = sequence.length();
        if (len > PARALLEL_THRESHOLD) {
            
            char[] chars = sequence.toCharArray();
            IntStream.range(0, len).parallel().forEach(i -> {
                if (!setToUse.contains(chars[i])) {
                    chars[i] = '-';
                }
            });
            return new String(chars);
        } else {
            StringBuilder cleanSeq = new StringBuilder(len);
            for (int i = 0; i < len; i++) {
                char c = sequence.charAt(i);
                if (!setToUse.contains(c)) {
                    cleanSeq.append('-');
                } else {
                    cleanSeq.append(c);
                }
            }
            return cleanSeq.toString();
        }
    }

    public static final String checkSequence(String sequence) {
        return checkSequence(sequence, null);
    }

    public static final String checkSequence(String sequence, Set<Character> cSet) {
        if (sequence == null) return null;
        Set<Character> setToUse = ensureHashSet(cSet);
        boolean containInvalid = doesSequenceContainInvalidChar(sequence, setToUse);
        if (containInvalid) {
            return cleanSequence(sequence, setToUse);
        } else {
            return sequence;
        }
    }
}
