package org.biojava.nbio.core.sequence.template;

import org.biojava.nbio.core.sequence.compound.NucleotideCompound;
import org.biojava.nbio.core.sequence.storage.ArrayListSequenceReader;
import org.biojava.nbio.core.sequence.views.ComplementSequenceView;
import org.biojava.nbio.core.sequence.views.ReversedSequenceView;
import org.biojava.nbio.core.sequence.views.WindowedSequence;
import org.biojava.nbio.core.util.CRC64Checksum;

import java.io.IOException;
import java.util.*;

public class SequenceMixin {
    private static final String[] GC_STRINGS = {"G", "C", "g", "c"};
    private static final String[] AT_STRINGS = {"A", "T", "a", "t"};

    public static <C extends Compound> int countCompounds(Sequence<C> sequence, C... compounds) {
        if (compounds == null || compounds.length == 0) return 0;
        if (compounds.length == 1) {
            
            C cmp = compounds[0];
            int count = 0;
            for (C c : sequence) {
                if (c.equals(cmp)) count++;
            }
            return count;
        } else {
            Set<C> compoundSet = new HashSet<>(Arrays.asList(compounds));
            int count = 0;
            for (C c : sequence) {
                if (compoundSet.contains(c)) count++;
            }
            return count;
        }
    }

    public static int countGC(Sequence<NucleotideCompound> sequence) {
        Set<NucleotideCompound> gcSet = new HashSet<>(4);
        Object cs = sequence.getCompoundSet();
        for (String s : GC_STRINGS) {
            try {
                NucleotideCompound nc = (NucleotideCompound) (cs.getClass().getMethod("getCompoundForString", String.class).invoke(cs, s));
                if (nc != null) gcSet.add(nc);
            } catch (Exception e) {
                
            }
        }
        int count = 0;
        for (NucleotideCompound nc : sequence) {
            if (gcSet.contains(nc)) count++;
        }
        return count;
    }

    public static int countAT(Sequence<NucleotideCompound> sequence) {
        Set<NucleotideCompound> atSet = new HashSet<>(4);
        Object cs = sequence.getCompoundSet();
        for (String s : AT_STRINGS) {
            try {
                NucleotideCompound nc = (NucleotideCompound) (cs.getClass().getMethod("getCompoundForString", String.class).invoke(cs, s));
                if (nc != null) atSet.add(nc);
            } catch (Exception e) {
                
            }
        }
        int count = 0;
        for (NucleotideCompound nc : sequence) {
            if (atSet.contains(nc)) count++;
        }
        return count;
    }

    public static <C extends Compound> Map<C, Integer> getComposition(Sequence<C> sequence) {
        int estimatedKeys = Math.max(16, (int)Math.min(sequence.getLength(), 128));
        Map<C, Integer> results = new HashMap<>(estimatedKeys);
        for (C c : sequence) {
            results.merge(c, 1, Integer::sum);
        }
        return results;
    }

    public static <C extends Compound> Map<C, Double> getDistribution(Sequence<C> sequence) {
        Map<C, Double> results = new HashMap<>();
        Map<C, Integer> composition = getComposition(sequence);
        double length = sequence.getLength();
        for (Map.Entry<C, Integer> entry : composition.entrySet()) {
            results.put(entry.getKey(), entry.getValue() / length);
        }
        return results;
    }

    public static <C extends Compound> void write(Appendable appendable, Sequence<C> sequence) throws IOException {
        if (appendable instanceof StringBuilder) {
            StringBuilder sb = (StringBuilder) appendable;
            for (C compound : sequence) {
                sb.append(compound.toString());
            }
        } else {
            for (C compound : sequence) {
                appendable.append(compound.toString());
            }
        }
    }

    public static <C extends Compound> StringBuilder toStringBuilder(Sequence<C> sequence) {
        StringBuilder sb = new StringBuilder(sequence.getLength());
        for (C compound : sequence) {
            sb.append(compound.toString());
        }
        return sb;
    }

    public static <C extends Compound> String toString(Sequence<C> sequence) {
        return toStringBuilder(sequence).toString();
    }

    public static <C extends Compound> List<C> toList(Sequence<C> sequence) {
        List<C> list = new ArrayList<>(sequence.getLength());
        for (C compound : sequence) {
            list.add(compound);
        }
        return list;
    }

    public static <C extends Compound> int indexOf(Sequence<C> sequence, C compound) {
        int index = 1;
        for (C currentCompound : sequence) {
            if (currentCompound.equals(compound)) {
                return index;
            }
            index++;
        }
        return 0;
    }

    public static <C extends Compound> int lastIndexOf(Sequence<C> sequence, C compound) {
        int len = sequence.getLength();
        for (int i = len; i >= 1; i--) {
            if (sequence.getCompoundAt(i).equals(compound)) {
                return i;
            }
        }
        return 0;
    }

    public static <C extends Compound> Iterator<C> createIterator(Sequence<C> sequence) {
        return new SequenceIterator<>(sequence);
    }

    public static <C extends Compound> SequenceView<C> createSubSequence(Sequence<C> sequence, int start, int end) {
        return new SequenceProxyView<>(sequence, start, end);
    }

    public static <C extends Compound> Sequence<C> shuffle(Sequence<C> sequence) {
        List<C> compounds = sequence.getAsList();
        Collections.shuffle(compounds);
        return new ArrayListSequenceReader<>(compounds, sequence.getCompoundSet());
    }

    public static <C extends Compound> String checksum(Sequence<C> sequence) {
        CRC64Checksum checksum = new CRC64Checksum();
        for (C compound : sequence) {
            checksum.update(compound.getShortName());
        }
        return checksum.toString();
    }

    public static <C extends Compound> List<SequenceView<C>> nonOverlappingKmers(Sequence<C> sequence, int kmer) {
        int maxKmers = Math.max(4, sequence.getLength()/Math.max(1, kmer));
        List<SequenceView<C>> l = new ArrayList<>(maxKmers);
        WindowedSequence<C> w = new WindowedSequence<>(sequence, kmer);
        for(SequenceView<C> view: w) {
            l.add(view);
        }
        return l;
    }

    public static <C extends Compound> List<SequenceView<C>> overlappingKmers(Sequence<C> sequence, int kmer) {
        int len = sequence.getLength();
        if (kmer <= 0 || kmer > len) return new ArrayList<>();
        int nKmers = len - kmer + 1;
        List<SequenceView<C>> l = new ArrayList<>(nKmers);
        for (int i = 1; i <= nKmers; i++) {
            l.add(sequence.getSubSequence(i, i + kmer - 1));
        }
        return l;
    }

    @SuppressWarnings({ "unchecked" })
    public static <C extends Compound> SequenceView<C> inverse(Sequence<C> sequence) {
        SequenceView<C> reverse = new ReversedSequenceView<>(sequence);
        if(sequence.getCompoundSet().isComplementable()) {
            return new ComplementSequenceView(reverse);
        }
        return reverse;
    }

    public static <C extends Compound> boolean sequenceEqualityIgnoreCase(Sequence<C> source, Sequence<C> target) {
        return baseSequenceEquality(source, target, true);
    }

    public static <C extends Compound> boolean sequenceEquality(Sequence<C> source, Sequence<C> target) {
        return baseSequenceEquality(source, target, false);
    }

    private static <C extends Compound> boolean baseSequenceEquality(Sequence<C> source, Sequence<C> target, boolean ignoreCase) {
        if(source.getLength() != target.getLength() ||
           !source.getCompoundSet().equals(target.getCompoundSet())) {
            return false;
        }
        Iterator<C> sIter = source.iterator();
        Iterator<C> tIter = target.iterator();
        while(sIter.hasNext()) {
            C s = sIter.next();
            C t = tIter.next();
            boolean cEqual = (ignoreCase) ? s.equalsIgnoreCase(t) : s.equals(t);
            if(!cEqual) {
                return false;
            }
        }
        return true;
    }

    public static class SequenceIterator<C extends Compound>
            implements Iterator<C> {
        private final Sequence<C> sequence;
        private final int length;
        private int currentPosition = 0;
        public SequenceIterator(Sequence<C> sequence) {
            this.sequence = sequence;
            this.length = sequence.getLength();
        }
        @Override
        public boolean hasNext() {
            return (currentPosition < length);
        }
        @Override
        public C next() {
            if(!hasNext()) {
                throw new NoSuchElementException("Exhausted sequence of elements");
            }
            return sequence.getCompoundAt(++currentPosition);
        }
        @Override
        public void remove() {
            throw new UnsupportedOperationException("Cannot remove() on a SequenceIterator");
        }
    }
}
