package org.biojava.nbio.core.sequence.template;

import org.biojava.nbio.core.exceptions.CompoundNotFoundException;
import org.biojava.nbio.core.sequence.AccessionID;
import org.biojava.nbio.core.sequence.DataSource;
import org.biojava.nbio.core.sequence.Strand;
import org.biojava.nbio.core.sequence.TaxonomyID;
import org.biojava.nbio.core.sequence.features.*;
import org.biojava.nbio.core.sequence.loader.UniprotProxySequenceReader;
import org.biojava.nbio.core.sequence.location.SequenceLocation;
import org.biojava.nbio.core.sequence.location.SimpleLocation;
import org.biojava.nbio.core.sequence.location.template.Location;
import org.biojava.nbio.core.sequence.reference.AbstractReference;
import org.biojava.nbio.core.sequence.storage.ArrayListSequenceReader;
import org.biojava.nbio.core.util.Equals;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.*;
import java.util.stream.Collectors;

public abstract class AbstractSequence<C extends Compound> implements Sequence<C> {

    private final static Logger logger = LoggerFactory.getLogger(AbstractSequence.class);

    private TaxonomyID taxonomy;
    private AccessionID accession;
    private SequenceReader<C> sequenceStorage = null;
    private CompoundSet<C> compoundSet;
    private AnnotationType annotationType = AnnotationType.UNKNOWN;
    private String description;
    private String originalHeader;
    private Collection<Object> userCollection;
    private Integer bioBegin = null;
    private Integer bioEnd = null;
    private AbstractSequence<?> parentSequence = null;
    private String source = null;
    private ArrayList<String> notesList = new ArrayList<String>();
    private Double sequenceScore = null;
    private FeaturesKeyWordInterface featuresKeyWord = null;
    private DatabaseReferenceInterface databaseReferences = null;
    private FeatureRetriever featureRetriever = null;
    private ArrayList<FeatureInterface<AbstractSequence<C>, C>> features =
            new ArrayList<FeatureInterface<AbstractSequence<C>, C>>();
    private LinkedHashMap<String, ArrayList<FeatureInterface<AbstractSequence<C>, C>>> groupedFeatures =
            new LinkedHashMap<String, ArrayList<FeatureInterface<AbstractSequence<C>, C>>>();
    private List<String> comments = new ArrayList<>();
    private List<AbstractReference> references;

    
    private boolean featuresDirty = false;
    private Set<String> groupedFeaturesDirty = new HashSet<>();
    private static final int PARALLEL_THRESHOLD = 1000;

    public AbstractSequence() {
    }

    public AbstractSequence(String seqString, CompoundSet<C> compoundSet) throws CompoundNotFoundException {
        setCompoundSet(compoundSet);
        initSequenceStorage(seqString);
    }

    protected void initSequenceStorage(String seqString) throws CompoundNotFoundException {
        sequenceStorage = new ArrayListSequenceReader<C>();
        sequenceStorage.setCompoundSet(this.getCompoundSet());
        sequenceStorage.setContents(seqString);
    }

    public AbstractSequence(SequenceReader<C> proxyLoader, CompoundSet<C> compoundSet) {
        setCompoundSet(compoundSet);
        setProxySequenceReader(proxyLoader);
    }

    public void setProxySequenceReader(SequenceReader<C> proxyLoader) {
        this.sequenceStorage = proxyLoader;
        if (proxyLoader instanceof FeaturesKeyWordInterface) {
            this.setFeaturesKeyWord((FeaturesKeyWordInterface) sequenceStorage);
        }
        if (proxyLoader instanceof DatabaseReferenceInterface) {
            this.setDatabaseReferences((DatabaseReferenceInterface) sequenceStorage);
        }

        if (proxyLoader instanceof FeatureRetriever) {
            this.setFeatureRetriever((FeatureRetriever) sequenceStorage);
            Map<String, List<AbstractFeature<AbstractSequence<C>, C>>> ff = getFeatureRetriever().getFeatures();
            for (String k: ff.keySet()){
                for (AbstractFeature f: ff.get(k)){
                    this.addFeature(f);
                }
            }
            ArrayList<DBReferenceInfo> dbQualifiers = (ArrayList)ff.get("source").get(0).getQualifiers().get("db_xref");
            DBReferenceInfo dbQualifier = dbQualifiers.get(0);
            if (dbQualifier != null) this.setTaxonomy(new TaxonomyID(dbQualifier.getDatabase()+":"+dbQualifier.getId(), DataSource.UNKNOWN));
        }

        if(getAccession() == null && proxyLoader instanceof UniprotProxySequenceReader){ 
            this.setAccession(proxyLoader.getAccession());
        }
    }

    public SequenceReader<C> getProxySequenceReader() {
        return sequenceStorage;
    }

    public Integer getBioBegin() {
        if (bioBegin == null) {
            return 1;
        } else {
            return bioBegin;
        }
    }

    public void setBioBegin(Integer bioBegin) {
        this.bioBegin = bioBegin;
    }

    public Integer getBioEnd() {
        if (bioEnd == null) {
            return this.getLength();
        } else {
            return bioEnd;
        }
    }

    public void setBioEnd(Integer bioEnd) {
        this.bioEnd = bioEnd;
    }

    public Collection<Object> getUserCollection() {
        return userCollection;
    }

    public void setUserCollection(Collection<Object> userCollection) {
        this.userCollection = userCollection;
    }

    public AnnotationType getAnnotationType() {
        return annotationType;
    }

    public void setAnnotationType(AnnotationType annotationType) {
        this.annotationType = annotationType;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getOriginalHeader() {
        return originalHeader;
    }

    public void setOriginalHeader(String originalHeader) {
        this.originalHeader = originalHeader;
    }

    public AbstractSequence<?> getParentSequence() {
        return parentSequence;
    }

    public void setParentSequence(AbstractSequence<?> parentSequence) {
        this.parentSequence = parentSequence;
    }

    public String getSource() {
        if (source != null) {
            return source;
        }
        if (parentSequence != null) {
            return parentSequence.getSource();
        }
        return null;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public void addNote(String note) {
        notesList.add(note);
    }

    public void removeNote(String note) {
        notesList.remove(note);
    }

    public ArrayList<String> getNotesList() {
        return notesList;
    }

    public void setNotesList(ArrayList<String> notesList) {
        this.notesList = notesList;
    }

    public Double getSequenceScore() {
        return sequenceScore;
    }

    public void setSequenceScore(Double sequenceScore) {
        this.sequenceScore = sequenceScore;
    }

    public List<AbstractReference> getReferences() {
        return references;
    }

    public void setReferences(List<AbstractReference> references) {
        this.references = references;
    }

    public List<FeatureInterface<AbstractSequence<C>, C>> getFeatures(String featureType, int bioSequencePosition) {
        List<FeatureInterface<AbstractSequence<C>, C>> featureHits;
        List<FeatureInterface<AbstractSequence<C>, C>> features = getFeaturesByType(featureType);
        if (features == null || features.isEmpty()) {
            featureHits = new ArrayList<FeatureInterface<AbstractSequence<C>, C>>();
            return featureHits;
        }
        
        if (features.size() > PARALLEL_THRESHOLD) {
            featureHits = features.parallelStream()
                .filter(feature -> bioSequencePosition >= feature.getLocations().getStart().getPosition()
                        && bioSequencePosition <= feature.getLocations().getEnd().getPosition())
                .collect(Collectors.toList());
        } else {
            featureHits = new ArrayList<FeatureInterface<AbstractSequence<C>, C>>();
            for (FeatureInterface<AbstractSequence<C>, C> feature : features) {
                if (bioSequencePosition >= feature.getLocations().getStart().getPosition() && bioSequencePosition <= feature.getLocations().getEnd().getPosition()) {
                    featureHits.add(feature);
                }
            }
        }
        return featureHits;
    }

    public List<FeatureInterface<AbstractSequence<C>, C>> getFeatures(int bioSequencePosition) {
        ensureFeaturesSorted();
        List<FeatureInterface<AbstractSequence<C>, C>> featureHits;
        if (features == null || features.isEmpty()) {
            featureHits = new ArrayList<FeatureInterface<AbstractSequence<C>, C>>();
            return featureHits;
        }
        
        if (features.size() > PARALLEL_THRESHOLD) {
            featureHits = features.parallelStream()
                .filter(feature -> bioSequencePosition >= feature.getLocations().getStart().getPosition()
                        && bioSequencePosition <= feature.getLocations().getEnd().getPosition())
                .collect(Collectors.toList());
        } else {
            featureHits = new ArrayList<FeatureInterface<AbstractSequence<C>, C>>();
            for (FeatureInterface<AbstractSequence<C>, C> feature : features) {
                if (bioSequencePosition >= feature.getLocations().getStart().getPosition() && bioSequencePosition <= feature.getLocations().getEnd().getPosition()) {
                    featureHits.add(feature);
                }
            }
        }
        return featureHits;
    }

    public List<FeatureInterface<AbstractSequence<C>, C>> getFeatures() {
        ensureFeaturesSorted();
        return features;
    }

    public void addFeature(int bioStart, int bioEnd, FeatureInterface<AbstractSequence<C>, C> feature) {
        SequenceLocation<AbstractSequence<C>, C> sequenceLocation =
                new SequenceLocation<AbstractSequence<C>, C>(bioStart, bioEnd, this);
        feature.setLocation(sequenceLocation);
        addFeature(feature);
    }

    public void addFeature(FeatureInterface<AbstractSequence<C>, C> feature) {
        features.add(feature);
        featuresDirty = true;
        ArrayList<FeatureInterface<AbstractSequence<C>, C>> featureList = groupedFeatures.get(feature.getType());
        if (featureList == null) {
            featureList = new ArrayList<FeatureInterface<AbstractSequence<C>, C>>();
            groupedFeatures.put(feature.getType(), featureList);
        }
        featureList.add(feature);
        groupedFeaturesDirty.add(feature.getType());
        
    }

    public void removeFeature(FeatureInterface<AbstractSequence<C>, C> feature) {
        features.remove(feature);
        featuresDirty = true;
        ArrayList<FeatureInterface<AbstractSequence<C>, C>> featureList = groupedFeatures.get(feature.getType());
        if (featureList != null) {
            featureList.remove(feature);
            groupedFeaturesDirty.add(feature.getType());
            if (featureList.isEmpty()) {
                groupedFeatures.remove(feature.getType());
                groupedFeaturesDirty.remove(feature.getType());
            }
        }
    }

    public List<FeatureInterface<AbstractSequence<C>, C>> getFeaturesByType(String type) {
        ArrayList<FeatureInterface<AbstractSequence<C>, C>> features = groupedFeatures.get(type);
        if (features == null) {
            features = new ArrayList<FeatureInterface<AbstractSequence<C>, C>>();
        } else {
            ensureGroupedFeaturesSorted(type);
        }
        return features;
    }

    public List<String> getComments() {
        return comments;
    }

    public void setComments(List<String> comments) {
        this.comments = comments;
    }

    public FeaturesKeyWordInterface getFeaturesKeyWord() {
        return featuresKeyWord;
    }

    public void setFeaturesKeyWord(FeaturesKeyWordInterface featuresKeyWord) {
        this.featuresKeyWord = featuresKeyWord;
    }

    public DatabaseReferenceInterface getDatabaseReferences() {
        return databaseReferences;
    }

    public void setDatabaseReferences(DatabaseReferenceInterface databaseReferences) {
        this.databaseReferences = databaseReferences;
    }

    public FeatureRetriever getFeatureRetriever() {
        return featureRetriever;
    }

    public void setFeatureRetriever(FeatureRetriever featureRetriever) {
        this.featureRetriever = featureRetriever;
    }

    public enum AnnotationType {
        CURATED, PREDICTED, UNKNOWN;
    }

    @Override
    public AccessionID getAccession() {
        return accession;
    }

    public void setAccession(AccessionID accession) {
        this.accession = accession;
    }

    public TaxonomyID getTaxonomy() {
        return taxonomy;
    }

    public void setTaxonomy(TaxonomyID taxonomy) {
        this.taxonomy = taxonomy;
    }

    @Override
    public CompoundSet<C> getCompoundSet() {
        if (compoundSet != null) {
            return compoundSet;
        }
        return null;
    }

    public void setCompoundSet(CompoundSet<C> compoundSet) {
        this.compoundSet = compoundSet;
    }

    @Override
    public boolean equals(Object o){
        if(! Equals.classEqual(this, o)) {
            return false;
        }
        Sequence<C> other = (Sequence<C>)o;
        if ( other.getCompoundSet() != getCompoundSet())
            return false;
        List<C> rawCompounds = getAsList();
        List<C> otherCompounds = other.getAsList();
        if ( rawCompounds.size() != otherCompounds.size())
            return false;
        for (int i = 0 ; i < rawCompounds.size() ; i++){
            Compound myCompound = rawCompounds.get(i);
            Compound otherCompound = otherCompounds.get(i);
            if ( ! myCompound.equalsIgnoreCase(otherCompound))
                return false;
        }
        return true;
    }

    @Override
    public int hashCode(){
        String s = getSequenceAsString();
        return s.hashCode();
    }

    @Override
    public String toString() {
        return getSequenceAsString();
    }

    private SequenceReader<C> getSequenceStorage() {
        if (sequenceStorage != null) {
            return sequenceStorage;
        }
        if (parentSequence != null) {
            if ( this.compoundSet.equals(parentSequence.getCompoundSet())){
                sequenceStorage = new ArrayListSequenceReader<C>();
                sequenceStorage.setCompoundSet(this.getCompoundSet());
                try {
                    sequenceStorage.setContents(parentSequence.getSequenceAsString());
                } catch (CompoundNotFoundException e) {
                    logger.error("Problem setting contents from parent sequence, some unrecognised compound: {}",e.getMessage());
                }
                return sequenceStorage;
            }
        }
        return null;
    }

    public String getSequenceAsString(Integer bioStart, Integer bioEnd, Strand strand) {
        Location loc = new SimpleLocation(bioStart, bioEnd, strand);
        return loc.getSubSequence(this).getSequenceAsString();
    }

    @Override
    public String getSequenceAsString() {
        return SequenceMixin.toString(this);
    }

    @Override
    public List<C> getAsList() {
        return sequenceStorage.getAsList();
    }

    @Override
    public C getCompoundAt(int position) {
        return getSequenceStorage().getCompoundAt(position);
    }

    @Override
    public int getIndexOf(C compound) {
        return getSequenceStorage().getIndexOf(compound);
    }

    @Override
    public int getLastIndexOf(C compound) {
        return getSequenceStorage().getLastIndexOf(compound);
    }

    @Override
    public int getLength() {
        return getSequenceStorage().getLength();
    }

    @Override
    public SequenceView<C> getSubSequence(final Integer bioStart, final Integer bioEnd) {
        return new SequenceProxyView<C>(this, bioStart, bioEnd);
    }

    @Override
    public Iterator<C> iterator() {
        return getSequenceStorage().iterator();
    }

    @Override
    public int countCompounds(C... compounds) {
        return SequenceMixin.countCompounds(this, compounds);
    }

    @Override
    public SequenceView<C> getInverse() {
        return SequenceMixin.inverse(this);
    }

    private void ensureFeaturesSorted() {
        if (featuresDirty) {
            synchronized (features) {
                if (featuresDirty) {
                    Collections.sort(features, AbstractFeature.LOCATION_LENGTH);
                    featuresDirty = false;
                }
            }
        }
    }

    private void ensureGroupedFeaturesSorted(String type) {
        ArrayList<FeatureInterface<AbstractSequence<C>, C>> featureList = groupedFeatures.get(type);
        if (featureList != null && groupedFeaturesDirty.contains(type)) {
            synchronized (featureList) {
                if (groupedFeaturesDirty.contains(type)) {
                    Collections.sort(featureList, AbstractFeature.LOCATION_LENGTH);
                    groupedFeaturesDirty.remove(type);
                }
            }
        }
    }
}
