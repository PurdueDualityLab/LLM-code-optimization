package org.biojava.nbio.core.sequence.compound;

import org.biojava.nbio.core.sequence.template.CompoundSet;
import org.biojava.nbio.core.sequence.template.Sequence;

import java.io.Serializable;
import java.util.*;

public class AminoAcidCompoundSet implements CompoundSet<AminoAcidCompound>, Serializable {

    private static final long serialVersionUID = 4000344194364133456L;
    private final Map<String, AminoAcidCompound> aminoAcidCompoundCache = new HashMap<String, AminoAcidCompound>();
    private final Map<String, AminoAcidCompound> aminoAcidCompoundCache3Letter = new HashMap<String, AminoAcidCompound>();
    private final Map<AminoAcidCompound, Set<AminoAcidCompound>> equivalentsCache = new HashMap<AminoAcidCompound, Set<AminoAcidCompound>>();
    private final Set<AminoAcidCompound> aminoAcidCompoundSet = new HashSet<AminoAcidCompound>();
    private final List<AminoAcidCompound> allCompounds;

    private static final AminoAcidCompoundSet aminoAcidCompoundSetSingleton = new AminoAcidCompoundSet(true);

    public AminoAcidCompoundSet() {
        this(false);
    }

    private AminoAcidCompoundSet(boolean eagerInit) {
        addCompound("A", "Ala", "Alanine", 71.0788f);
        addCompound("R", "Arg", "Arginine", 156.1875f);
        addCompound("N", "Asn", "Asparagine", 114.1039f);
        addCompound("D", "Asp", "Aspartic acid", 115.0886f);
        addCompound("C", "Cys", "Cysteine", 103.1388f);
        addCompound("E", "Glu", "Glutamic acid", 129.1155f);
        addCompound("Q", "Gln", "Glutamine", 128.1307f);
        addCompound("G", "Gly", "Glycine", 57.0519f);
        addCompound("H", "His", "Histidine", 137.1411f);
        addCompound("I", "Ile", "Isoleucine", 113.1594f);
        addCompound("L", "Leu", "Leucine", 113.1594f);
        addCompound("K", "Lys", "Lysine", 128.1741f);
        addCompound("M", "Met", "Methionine", 131.1986f);
        addCompound("F", "Phe", "Phenylalanine", 147.1766f);
        addCompound("P", "Pro", "Proline", 97.1167f);
        addCompound("S", "Ser", "Serine", 87.0782f);
        addCompound("T", "Thr", "Threonine", 101.1051f);
        addCompound("W", "Trp", "Tryptophan", 186.2132f);
        addCompound("Y", "Tyr", "Tyrosine", 163.1760f);
        addCompound("V", "Val", "Valine", 99.1326f);
        addCompound("B", "Asx", "Asparagine or Aspartic acid", null);
        addCompound("Z", "Glx", "Glutamine or Glutamic acid", null);
        addCompound("J", "Xle", "Leucine or Isoleucine", null);
        addCompound("X", "Xaa", "Unspecified", null);
        addCompound("-", "---", "Unspecified", null);
        addCompound(".", "...", "Unspecified", null);
        addCompound("_", "___", "Unspecified", null);
        addCompound("*", "***", "Stop", null);
        addCompound("U", "Sec", "Selenocysteine", 150.0388f);
        addCompound("O", "Pyl", "Pyrrolysine", 255.3172f);

        allCompounds = Collections.unmodifiableList(new ArrayList<AminoAcidCompound>(aminoAcidCompoundSet));
        if (eagerInit) {
            initEquivalentsCache();
        }
    }

    private void addCompound(String oneLetter, String threeLetter, String fullName, Float mass) {
        String canonicalOne = canonicalizeKey(oneLetter);
        AminoAcidCompound compound = new AminoAcidCompound(this, canonicalOne, threeLetter, fullName, mass);
        aminoAcidCompoundCache.put(canonicalOne, compound);
        aminoAcidCompoundCache3Letter.put(canonicalizeKey(fullName), compound); 
        aminoAcidCompoundSet.add(compound);
    }

    private static String canonicalizeKey(String key) {
        return key == null ? null : key.toUpperCase(Locale.ROOT);
    }

    public static AminoAcidCompoundSet getAminoAcidCompoundSet() {
        return aminoAcidCompoundSetSingleton;
    }

    @Override
    public String getStringForCompound(AminoAcidCompound compound) {
        return compound.toString();
    }

    @Override
    public AminoAcidCompound getCompoundForString(String string) {
        if (string == null || string.length() == 0) {
            return null;
        }
        String canon = canonicalizeKey(string);
        if (canon.length() == 3) {
            return this.aminoAcidCompoundCache3Letter.get(canon);
        }
        if (canon.length() > this.getMaxSingleCompoundStringLength()) {
            throw new IllegalArgumentException("String supplied ("+string+") is too long. Max is "+getMaxSingleCompoundStringLength());
        }
        return this.aminoAcidCompoundCache.get(canon);
    }

    @Override
    public int getMaxSingleCompoundStringLength() {
        return 1;
    }

    @Override
    public boolean isCompoundStringLengthEqual() {
        return true;
    }

    @Override
    public boolean compoundsEquivalent(AminoAcidCompound compoundOne, AminoAcidCompound compoundTwo) {
        Set<AminoAcidCompound> equivalents = getEquivalentCompounds(compoundOne);
        return (equivalents != null) && equivalents.contains(compoundTwo);
    }

    @Override
    public Set<AminoAcidCompound> getEquivalentCompounds(AminoAcidCompound compound) {
        
        if (equivalentsCache.isEmpty()) {
            synchronized (equivalentsCache) {
                if (equivalentsCache.isEmpty()) {
                    initEquivalentsCache();
                }
            }
        }
        return equivalentsCache.get(compound);
    }

    private void initEquivalentsCache() {
        for (AminoAcidCompound c : aminoAcidCompoundSet) {
            equivalentsCache.put(c, Collections.singleton(c));
        }
        addAmbiguousEquivalents("N", "D", "B");
        addAmbiguousEquivalents("E", "Q", "Z");
        addAmbiguousEquivalents("I", "L", "J");
        
        AminoAcidCompound gap1 = aminoAcidCompoundCache.get(canonicalizeKey("-"));
        AminoAcidCompound gap2 = aminoAcidCompoundCache.get(canonicalizeKey("."));
        AminoAcidCompound gap3 = aminoAcidCompoundCache.get(canonicalizeKey("_"));
        Set<AminoAcidCompound> gaps = new HashSet<AminoAcidCompound>();
        if (gap1 != null) gaps.add(gap1);
        if (gap2 != null) gaps.add(gap2);
        if (gap3 != null) gaps.add(gap3);
        if (!gaps.isEmpty()) {
            if (gap1 != null) equivalentsCache.put(gap1, gaps);
            if (gap2 != null) equivalentsCache.put(gap2, gaps);
            if (gap3 != null) equivalentsCache.put(gap3, gaps);
        }
        equivalentsCache.put(aminoAcidCompoundCache.get(canonicalizeKey("X")), new HashSet<AminoAcidCompound>());
    }

    private void addAmbiguousEquivalents(String one, String two, String either) {
        AminoAcidCompound cOne = aminoAcidCompoundCache.get(canonicalizeKey(one));
        AminoAcidCompound cTwo = aminoAcidCompoundCache.get(canonicalizeKey(two));
        AminoAcidCompound cEither = aminoAcidCompoundCache.get(canonicalizeKey(either));
        Set<AminoAcidCompound> equivalents = new HashSet<AminoAcidCompound>();
        equivalents.add(cOne);
        equivalents.add(cTwo);
        equivalents.add(cEither);
        equivalentsCache.put(cEither, equivalents);
        equivalents = new HashSet<AminoAcidCompound>();
        equivalents.add(cOne);
        equivalents.add(cEither);
        equivalentsCache.put(cOne, equivalents);
        equivalents = new HashSet<AminoAcidCompound>();
        equivalents.add(cTwo);
        equivalents.add(cEither);
        equivalentsCache.put(cTwo, equivalents);
    }

    @Override
    public boolean hasCompound(AminoAcidCompound compound) {
        return aminoAcidCompoundSet.contains(compound);
    }

    @Override
    public boolean isValidSequence(Sequence<AminoAcidCompound> sequence) {
        for (AminoAcidCompound compound : sequence) {
            if (!hasCompound(compound)) {
                return false;
            }
        }
        return true;
    }

    @Override
    public List<AminoAcidCompound> getAllCompounds() {
        return allCompounds;
    }

    @Override
    public boolean isComplementable() {
        return false;
    }
}
