package org.biojava.nbio.core.sequence.compound;

import java.io.Serializable;

import org.biojava.nbio.core.sequence.template.AbstractCompound;
import org.biojava.nbio.core.sequence.template.Compound;
import org.biojava.nbio.core.sequence.template.CompoundSet;

public class AminoAcidCompound extends AbstractCompound implements Serializable {

    private static final long serialVersionUID = -1955116496725902319L;
    private final AminoAcidCompoundSet compoundSet;
    
    private transient String cachedToString;
    private final int cachedHashCode;

    public AminoAcidCompound(AminoAcidCompoundSet compoundSet, String shortName,
                             String longName, String description, Float molecularWeight) {
        super(shortName);
        setShortName(shortName);
        setLongName(longName);
        setDescription(description);
        setMolecularWeight(molecularWeight);
        this.compoundSet = compoundSet;
        
        this.cachedHashCode = computeHashCode();
    }

    @Override
    public String toString() {
        if (cachedToString == null) {
            cachedToString = super.toString();
        }
        return cachedToString;
    }

    private int computeHashCode() {
        
        return toString().hashCode();
    }

    @Override
    public int hashCode() {
        return cachedHashCode;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof AminoAcidCompound)) {
            return false;
        }
        AminoAcidCompound them = (AminoAcidCompound) obj;
        
        String thisStr = this.toString();
        String themStr = them.toString();
        if (thisStr.equals(themStr)) {
            return true;
        }
        String thisLong = this.getLongName();
        String themLong = them.getLongName();
        return thisLong.equals(themLong);
    }

    @Override
    public boolean equalsIgnoreCase(Compound compound) {
        if (compound == null) {
            return false;
        }
        if (this == compound) {
            return true;
        }
        if (!(compound instanceof AminoAcidCompound)) {
            return false;
        }
        AminoAcidCompound them = (AminoAcidCompound) compound;
        String thisStr = this.toString();
        String themStr = them.toString();
        if (thisStr.equalsIgnoreCase(themStr)) {
            return true;
        }
        String thisLong = this.getLongName();
        String themLong = them.getLongName();
        return thisLong.equalsIgnoreCase(themLong);
    }

    public CompoundSet<AminoAcidCompound> getCompoundSet() {
        return compoundSet;
    }
}
