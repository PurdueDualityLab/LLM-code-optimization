package org.biojava.nbio.core.sequence;

import org.biojava.nbio.core.exceptions.CompoundNotFoundException;
import org.biojava.nbio.core.sequence.compound.*;
import org.biojava.nbio.core.sequence.features.FeatureInterface;
import org.biojava.nbio.core.sequence.io.DNASequenceCreator;
import org.biojava.nbio.core.sequence.io.FastaReader;
import org.biojava.nbio.core.sequence.io.PlainFastaHeaderParser;
import org.biojava.nbio.core.sequence.location.InsdcParser;
import org.biojava.nbio.core.sequence.location.template.Location;
import org.biojava.nbio.core.sequence.template.AbstractSequence;
import org.biojava.nbio.core.sequence.template.CompoundSet;
import org.biojava.nbio.core.sequence.template.ProxySequenceReader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.biojava.nbio.core.sequence.features.Qualifier;





public class ProteinSequence extends AbstractSequence<AminoAcidCompound> {

    private final static Logger logger = LoggerFactory.getLogger(ProteinSequence.class);

    
    
    private static final int CACHE_MAX_SIZE = 1000;
    private static final Map<String, DNASequence> parentSequenceCache = new LinkedHashMap<String, DNASequence>(16, 0.75f, true) {
        @Override
        protected boolean removeEldestEntry(Map.Entry<String, DNASequence> eldest) {
            return size() > CACHE_MAX_SIZE;
        }
    };
    private static final Object cacheLock = new Object();
    

    public ProteinSequence(String seqString) throws CompoundNotFoundException {
        this(seqString, AminoAcidCompoundSet.getAminoAcidCompoundSet());
    }

    public ProteinSequence(String seqString, CompoundSet<AminoAcidCompound> compoundSet) throws CompoundNotFoundException {
        super(seqString, compoundSet);
    }

    public ProteinSequence(ProxySequenceReader<AminoAcidCompound> proxyLoader) {
        this(proxyLoader, AminoAcidCompoundSet.getAminoAcidCompoundSet());
    }

    public ProteinSequence(ProxySequenceReader<AminoAcidCompound> proxyLoader, CompoundSet<AminoAcidCompound> compoundSet) {
        super(proxyLoader, compoundSet);

        List<FeatureInterface<AbstractSequence<AminoAcidCompound>, AminoAcidCompound>> CDSFeatures = getFeaturesByType("CDS");

        if (CDSFeatures.size() == 1) {
            FeatureInterface<AbstractSequence<AminoAcidCompound>, AminoAcidCompound> feature = CDSFeatures.get(0);
            Map<String, List<Qualifier>> qualifiers = feature.getQualifiers();
            List<Qualifier> codedByList = qualifiers != null ? qualifiers.get("coded_by") : null;
            Qualifier codedBy = (codedByList != null && !codedByList.isEmpty()) ? codedByList.get(0) : null;

            if (codedBy != null) {
                String codedBySeq = codedBy.getValue();
                InsdcParser parser = new InsdcParser(DataSource.GENBANK);
                Location location = parser.parse(codedBySeq);

                try {
                    DNASequence dnaSeq = new DNASequence(getSequence(location), DNACompoundSet.getDNACompoundSet());
                    setParentDNASequence(dnaSeq, location.getStart().getPosition(), location.getEnd().getPosition());
                } catch (CompoundNotFoundException e) {
                    logger.error("Could not add 'coded_by' parent DNA location feature, unrecognised compounds found in DNA sequence: {}", e.getMessage());
                }
            }
        }
    }

    public void setParentDNASequence(AbstractSequence<NucleotideCompound> parentDNASequence, Integer begin, Integer end) {
        this.setParentSequence(parentDNASequence);
        setBioBegin(begin);
        setBioEnd(end);
    }

    private DNASequence getRawParentSequence(String accessId) throws IOException {
        
        DNASequence cachedSeq;
        synchronized (cacheLock) {
            cachedSeq = parentSequenceCache.get(accessId);
            if (cachedSeq != null) {
                return cachedSeq;
            }
        }
        String seqUrlTemplate = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=nuccore&id=%s&rettype=fasta&retmode=text";
        URL url = new URL(String.format(seqUrlTemplate, accessId));

        logger.trace("Getting parent DNA sequence from URL: {}", url.toString());

        
        InputStream is = new BufferedInputStream(url.openConnection().getInputStream());
        try {
            FastaReader<DNASequence, NucleotideCompound> parentReader
                    = new FastaReader<DNASequence, NucleotideCompound>(is,
                            new PlainFastaHeaderParser<DNASequence, NucleotideCompound>(),
                            new DNASequenceCreator(AmbiguityDNACompoundSet.getDNACompoundSet()));
            LinkedHashMap<String, DNASequence> seq = parentReader.process();

            DNASequence parentSeq = null;
            if (seq.size() == 1) {
                parentSeq = seq.values().iterator().next();
            }
            if (parentSeq != null) {
                synchronized (cacheLock) {
                    parentSequenceCache.put(accessId, parentSeq);
                }
            }
            return parentSeq;
        } finally {
            is.close();
        }
    }

    private String getSequence(Location cdna) {
        if (!cdna.isComplex()) {
            try {
                DNASequence rawParent = getRawParentSequence(cdna.getAccession().getID());
                return cdna.getSubSequence(rawParent).getSequenceAsString();
            } catch (IOException e) {
                logger.error("Caught IOException when getting DNA sequence for id {}. Error: {}", cdna.getAccession().getID(), e.getMessage());
                return null;
            }
        } else {
            StringBuilder sb = new StringBuilder();
            for (Location sub : cdna.getSubLocations()) {
                String sebStr = getSequence(sub);
                sb.append((sebStr == null ? "" : sebStr));
            }
            return sb.toString();
        }
    }
}
