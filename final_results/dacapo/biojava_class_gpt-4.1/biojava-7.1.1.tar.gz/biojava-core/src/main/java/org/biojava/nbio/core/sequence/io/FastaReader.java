package org.biojava.nbio.core.sequence.io;

import org.biojava.nbio.core.exceptions.CompoundNotFoundException;
import org.biojava.nbio.core.sequence.ProteinSequence;
import org.biojava.nbio.core.sequence.compound.AminoAcidCompound;
import org.biojava.nbio.core.sequence.compound.AminoAcidCompoundSet;
import org.biojava.nbio.core.sequence.io.template.SequenceCreatorInterface;
import org.biojava.nbio.core.sequence.io.template.SequenceHeaderParserInterface;
import org.biojava.nbio.core.sequence.template.Compound;
import org.biojava.nbio.core.sequence.template.Sequence;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.util.LinkedHashMap;

public class FastaReader<S extends Sequence<?>, C extends Compound> {
    private final static Logger logger = LoggerFactory.getLogger(FastaReader.class);

    SequenceCreatorInterface<C> sequenceCreator;
    SequenceHeaderParserInterface<S, C> headerParser;
    BufferedReaderBytesRead br;
    InputStreamReader isr;
    FileInputStream fi = null;
    long fileIndex = 0;
    long sequenceIndex = 0;
    String line = "";
    String header = "";

    public FastaReader(InputStream is, SequenceHeaderParserInterface<S, C> headerParser,
                       SequenceCreatorInterface<C> sequenceCreator) {
        this.headerParser = headerParser;
        isr = new InputStreamReader(is);
        this.br = new BufferedReaderBytesRead(isr);
        this.sequenceCreator = sequenceCreator;
    }

    public FastaReader(File file, SequenceHeaderParserInterface<S, C> headerParser,
                       SequenceCreatorInterface<C> sequenceCreator) throws FileNotFoundException {
        this.headerParser = headerParser;
        fi = new FileInputStream(file);
        isr = new InputStreamReader(fi);
        this.br = new BufferedReaderBytesRead(isr);
        this.sequenceCreator = sequenceCreator;
    }

    public LinkedHashMap<String, S> process() throws IOException {
        LinkedHashMap<String, S> sequences = process(-1);
        close();
        return sequences;
    }

    public LinkedHashMap<String, S> process(int max) throws IOException {
        
        StringBuilder sb = new StringBuilder();
        int processedSequences = 0;
        LinkedHashMap<String, S> sequences = new LinkedHashMap<>();
        boolean eof = false;

        
        if (this.line == null) this.line = "";
        if (this.header == null) this.header = "";

        while (!eof) {
            String currLine = this.line;
            int currLineLen = currLine.length();
            if (currLineLen != 0) {
                char firstChar = currLine.charAt(0);
                if (Character.isWhitespace(firstChar)) {
                    currLine = currLine.trim();
                    currLineLen = currLine.length();
                }
                if (currLineLen != 0) {
                    if (currLine.charAt(0) == '>') {
                        if (sb.length() > 0) {
                            try {
                                @SuppressWarnings("unchecked")
                                S sequence = (S) sequenceCreator.getSequence(sb.toString(), sequenceIndex);
                                headerParser.parseHeader(this.header, sequence);
                                sequences.put(sequence.getAccession().getID(), sequence);
                                processedSequences++;
                            } catch (CompoundNotFoundException e) {
                                logger.warn("Sequence with header '{}' has unrecognised compounds ({}), it will be ignored",
                                        this.header, e.getMessage());
                            }
                            sb.setLength(0);
                        }
                        this.header = currLine.substring(1);
                    } else if (currLine.charAt(0) != ';') {
                        if (sb.length() == 0) {
                            sequenceIndex = fileIndex;
                        }
                        sb.append(currLine);
                    } 
                }
            }
            fileIndex = br.getBytesRead();
            this.line = br.readLine();
            if (this.line == null) {
                eof = true;
                if (sb.length() == 0 && this.header.length() != 0) {
                    logger.warn("Can't parse sequence {}. Got sequence of length 0!", sequenceIndex);
                    logger.warn("header: {}", this.header);
                    this.header = null;
                } else if (sb.length() > 0) {
                    try {
                        @SuppressWarnings("unchecked")
                        S sequence = (S) sequenceCreator.getSequence(sb.toString(), sequenceIndex);
                        headerParser.parseHeader(this.header, sequence);
                        sequences.put(sequence.getAccession().getID(), sequence);
                        processedSequences++;
                        this.header = null;
                    } catch (CompoundNotFoundException e) {
                        logger.warn("Sequence with header '{}' has unrecognised compounds ({}), it will be ignored",
                                this.header, e.getMessage());
                    }
                }
            }
            if (max > -1 && processedSequences >= max) {
                break;
            }
        }
        return (max > -1 && sequences.isEmpty()) ? null : sequences;
    }

    public void close() throws IOException {
        IOException ex = null;
        try { if (br != null) br.close(); } catch (IOException e) { ex = e; }
        try { if (isr != null) isr.close(); } catch (IOException e) { ex = e; }
        try { if (fi != null) fi.close(); } catch (IOException e) { ex = e; }
        this.line = null;
        this.header = null;
        if (ex != null) throw ex;
    }
}
