package org.biojava.nbio.core.sequence.io;

import org.biojava.nbio.core.exceptions.CompoundNotFoundException;
import org.biojava.nbio.core.sequence.AccessionID;
import org.biojava.nbio.core.sequence.DataSource;
import org.biojava.nbio.core.sequence.ProteinSequence;
import org.biojava.nbio.core.sequence.compound.AminoAcidCompound;
import org.biojava.nbio.core.sequence.io.template.SequenceHeaderParserInterface;
import org.biojava.nbio.core.sequence.template.AbstractSequence;
import org.biojava.nbio.core.sequence.template.AbstractSequence.AnnotationType;
import org.biojava.nbio.core.sequence.template.Compound;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

public class GenericFastaHeaderParser<S extends AbstractSequence<C>, C extends Compound> implements SequenceHeaderParserInterface<S,C> {

    private static final Logger logger = LoggerFactory.getLogger(GenericFastaHeaderParser.class);
    private static final String PDB_PREFIX = "PDB:";
    private static final String PIPE = "|";
    private static final String SPACE = " ";

    
    private static String[] fastSplit(String str, char delimiter) {
        List<String> tokens = new ArrayList<>();
        int start = 0;
        int len = str.length();
        for (int i = 0; i < len; i++) {
            if (str.charAt(i) == delimiter) {
                tokens.add(str.substring(start, i));
                start = i + 1;
            }
        }
        if (start <= len - 1) tokens.add(str.substring(start));
        return tokens.toArray(new String[tokens.size()]);
    }

    private static String[] fastSpaceSplit(String str) {
        
        List<String> tokens = new ArrayList<>();
        int start = 0;
        int len = str.length();
        for (int i = 0; i < len; i++) {
            if (str.charAt(i) == ' ') {
                tokens.add(str.substring(start, i));
                start = i + 1;
            }
        }
        if (start <= len - 1) tokens.add(str.substring(start));
        return tokens.toArray(new String[tokens.size()]);
    }

    private static String[] getHeaderValues(String header) {
        if (!header.startsWith(PDB_PREFIX)) {
            return fastSplit(header, '|');
        } else {
            return fastSpaceSplit(header);
        }
    }

    @Override
    public void parseHeader(String header, S sequence) {
        sequence.setOriginalHeader(header);
        String[] data = getHeaderValues(header);

        if (data.length == 1) {
            sequence.setAccession(new AccessionID(data[0]));
        } else if ("sp".equalsIgnoreCase(data[0]) || "tr".equalsIgnoreCase(data[0])) {
            if ("sp".equalsIgnoreCase(data[0])) {
                sequence.setAnnotationType(AnnotationType.CURATED);
            } else {
                sequence.setAnnotationType(AnnotationType.PREDICTED);
            }
            sequence.setAccession(new AccessionID(data[1], DataSource.UNIPROT));
            if (data.length > 2) {
                sequence.setDescription(data[2]);
            }
        } else if ("gi".equalsIgnoreCase(data[0])) {
            DataSource giSource = DataSource.UNKNOWN;
            if (data.length >= 3) {
                if ("gb".equalsIgnoreCase(data[2])) {
                    giSource = DataSource.GENBANK;
                } else if ("emb".equalsIgnoreCase(data[2])) {
                    giSource = DataSource.ENA;
                } else if ("dbj".equalsIgnoreCase(data[2])) {
                    giSource = DataSource.DDBJ;
                }
                sequence.setAccession(new AccessionID(data[3], giSource));
            } else {
                sequence.setAccession(new AccessionID(header, giSource));
            }
        } else if ("pir".equalsIgnoreCase(data[0])) {
            sequence.setAccession(new AccessionID(data[2], DataSource.NBRF));
        } else if ("prf".equalsIgnoreCase(data[0])) {
            sequence.setAccession(new AccessionID(data[2], DataSource.PRF));
        } else if ("pdb".equalsIgnoreCase(data[0])) {
            sequence.setAccession(new AccessionID(data[1] + ":" + data[2], DataSource.PDB1));
        } else if (data[0].startsWith("PDB")) {
            
            int colonIdx = data[0].indexOf(':');
            if (colonIdx != -1 && colonIdx + 1 < data[0].length()) {
                String accession = data[0].substring(colonIdx + 1);
                sequence.setAccession(new AccessionID(accession, DataSource.PDBe));
            } else {
                sequence.setAccession(new AccessionID(data[0], DataSource.PDBe));
            }
        } else if (data[0].indexOf(":") != -1 && data.length > 1 && "PDBID".equals(data[1])) {
            sequence.setAccession(new AccessionID(data[0], DataSource.PDB2));
        } else if ("pat".equalsIgnoreCase(data[0])) {
            sequence.setAccession(new AccessionID(data[2], DataSource.PATENTS));
        } else if ("bbs".equalsIgnoreCase(data[0])) {
            sequence.setAccession(new AccessionID(data[1], DataSource.GENINFO));
        } else if ("gnl".equalsIgnoreCase(data[0])) {
            sequence.setAccession(new AccessionID(data[2], DataSource.GENERAL));
        } else if ("ref".equalsIgnoreCase(data[0])) {
            sequence.setAccession(new AccessionID(data[1], DataSource.NCBI));
        } else if ("lcl".equalsIgnoreCase(data[0])) {
            sequence.setAccession(new AccessionID(data[1], DataSource.LOCAL));
        } else {
            sequence.setAccession(new AccessionID(data[0]));
        }
    }
}
