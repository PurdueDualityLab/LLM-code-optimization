
package org.biojava.nbio.core.sequence.io;

import org.biojava.nbio.core.exceptions.CompoundNotFoundException;
import org.biojava.nbio.core.sequence.ProteinSequence;
import org.biojava.nbio.core.sequence.compound.AminoAcidCompound;
import org.biojava.nbio.core.sequence.compound.AminoAcidCompoundSet;
import org.biojava.nbio.core.sequence.io.template.SequenceCreatorInterface;
import org.biojava.nbio.core.sequence.io.template.SequenceHeaderParserInterface;
import org.biojava.nbio.core.sequence.template.Compound;
import org.biojava.nbio.core.sequence.template.Sequence;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.util.HashMap;
import java.util.LinkedHashMap;


public class FastaReader<S extends Sequence<?>, C extends Compound> {

	private final static Logger logger = LoggerFactory.getLogger(FastaReader.class);

	SequenceCreatorInterface<C> sequenceCreator;
	SequenceHeaderParserInterface<S,C> headerParser;
	BufferedReaderBytesRead br;
	InputStreamReader isr;
	FileInputStream fi = null;
	long fileIndex = 0;
	long sequenceIndex = 0;
	String line = "";
	String header= "";

	
	public FastaReader(InputStream is, SequenceHeaderParserInterface<S,C> headerParser,
					   SequenceCreatorInterface<C> sequenceCreator) {
		this.headerParser = headerParser;
		isr = new InputStreamReader(is);
		this.br = new BufferedReaderBytesRead(isr);
		this.sequenceCreator = sequenceCreator;
	}

	
	public FastaReader(File file, SequenceHeaderParserInterface<S,C> headerParser,
					   SequenceCreatorInterface<C> sequenceCreator) throws FileNotFoundException {
		this.headerParser = headerParser;
		fi = new FileInputStream(file);
		isr = new InputStreamReader(fi);
		this.br = new BufferedReaderBytesRead(isr);
		this.sequenceCreator = sequenceCreator;
	}

	
	public LinkedHashMap<String,S> process() throws IOException {
		LinkedHashMap<String,S> sequences = process(-1);
		close();

		return sequences;
	}

	
	public LinkedHashMap<String,S> process(int max) throws IOException {


		String line = "";
		if(this.line != null && this.line.length() > 0){
			line=this.line;
		}
		String header = "";
		if(this.header != null && this.header.length() > 0){
			header=this.header;
		}

		StringBuilder sb = new StringBuilder();
		int processedSequences=0;
		boolean keepGoing = true;


		LinkedHashMap<String,S> sequences = new LinkedHashMap<String,S>();

		do {
			line = line.trim(); 
			if (line.length() != 0) {
				if (line.startsWith(">")) {

					if (sb.length() > 0) {
						
						

						try {
							@SuppressWarnings("unchecked")
							S sequence = (S)sequenceCreator.getSequence(sb.toString(), sequenceIndex);
							headerParser.parseHeader(header, sequence);
							sequences.put(sequence.getAccession().getID(),sequence);
							processedSequences++;

						} catch (CompoundNotFoundException e) {
							logger.warn("Sequence with header '{}' has unrecognised compounds ({}), it will be ignored",
									header, e.getMessage());
						}

						sb.setLength(0); 
					}
					header = line.substring(1);
				} else if (line.startsWith(";")) {
				} else {
					
					if(sb.length() == 0){
						sequenceIndex = fileIndex;
					}
					sb.append(line);
				}
			}
			fileIndex = br.getBytesRead();

			line = br.readLine();

			if (line == null) {
				
				if ( sb.length() == 0 && header.length() != 0 ) {
					logger.warn("Can't parse sequence {}. Got sequence of length 0!", sequenceIndex);
					logger.warn("header: {}", header);
					header = null;
				} else if ( sb.length() > 0 ) {
					
					try {
						@SuppressWarnings("unchecked")
						S sequence = (S)sequenceCreator.getSequence(sb.toString(), sequenceIndex);
						headerParser.parseHeader(header, sequence);
						sequences.put(sequence.getAccession().getID(),sequence);
						processedSequences++;
						header = null;
					} catch (CompoundNotFoundException e) {
						logger.warn("Sequence with header '{}' has unrecognised compounds ({}), it will be ignored",
								header, e.getMessage());
					}
				}
				keepGoing = false;
			}
			if (max > -1 && processedSequences>=max) {
				keepGoing=false;
			}
		} while (keepGoing);

		this.line  = line;
		this.header= header;

		return max > -1 && sequences.isEmpty() ? null :  sequences;
	}

	public void close() throws IOException {
		br.close();
		isr.close();
		
		if (fi != null) {
			fi.close();
		}
		this.line=this.header = null;
	}
	
}
