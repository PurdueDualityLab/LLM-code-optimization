package org.biojava.nbio.core.sequence.template;

import org.biojava.nbio.core.sequence.compound.NucleotideCompound;
import org.biojava.nbio.core.sequence.storage.ArrayListSequenceReader;
import org.biojava.nbio.core.sequence.views.ComplementSequenceView;
import org.biojava.nbio.core.sequence.views.ReversedSequenceView;
import org.biojava.nbio.core.sequence.views.WindowedSequence;
import org.biojava.nbio.core.util.CRC64Checksum;

import java.io.IOException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class SequenceMixin {

    
    private static final Map<String, NucleotideCompound> nucleotideCache = new ConcurrentHashMap<>();

    private static NucleotideCompound getCachedCompound(CompoundSet<NucleotideCompound> cs, String name) {
        return nucleotideCache.computeIfAbsent(name, cs::getCompoundForString);
    }

    public static <C extends Compound> int countCompounds(
            Sequence<C> sequence, C... compounds) {
        Map<C, Integer> composition = getComposition(sequence);
        int count = 0;
        for (C compound : compounds) {
            count += composition.getOrDefault(compound, 0);
        }
        return count;
    }

    public static int countGC(Sequence<NucleotideCompound> sequence) {
        CompoundSet<NucleotideCompound> cs = sequence.getCompoundSet();
        return countCompounds(sequence, getCachedCompound(cs, "G"), getCachedCompound(cs, "C"),
                getCachedCompound(cs, "g"), getCachedCompound(cs, "c"));
    }

    public static int countAT(Sequence<NucleotideCompound> sequence) {
        CompoundSet<NucleotideCompound> cs = sequence.getCompoundSet();
        return countCompounds(sequence, getCachedCompound(cs, "A"), getCachedCompound(cs, "T"),
                getCachedCompound(cs, "a"), getCachedCompound(cs, "t"));
    }

    public static <C extends Compound> Map<C, Double> getDistribution(Sequence<C> sequence) {
        Map<C, Integer> composition = getComposition(sequence);
        double length = sequence.getLength();
        Map<C, Double> results = new HashMap<>();
        for (Map.Entry<C, Integer> entry : composition.entrySet()) {
            results.put(entry.getKey(), entry.getValue() / length);
        }
        return results;
    }

    public static <C extends Compound> Map<C, Integer> getComposition(Sequence<C> sequence) {
        Map<C, Integer> results = new HashMap<>();
        for (C currentCompound : sequence) {
            results.merge(currentCompound, 1, Integer::sum);
        }
        return results;
    }

    public static <C extends Compound> void write(Appendable appendable, Sequence<C> sequence) throws IOException {
        StringBuilder sb = new StringBuilder(sequence.getLength());
        for (C compound : sequence) {
            sb.append(compound.toString());
        }
        appendable.append(sb);
    }

    public static <C extends Compound> StringBuilder toStringBuilder(Sequence<C> sequence) {
        StringBuilder sb = new StringBuilder(sequence.getLength());
        for (C compound : sequence) {
            sb.append(compound.toString());
        }
        return sb;
    }

    public static <C extends Compound> String toString(Sequence<C> sequence) {
        return toStringBuilder(sequence).toString();
    }

    public static <C extends Compound> List<C> toList(Sequence<C> sequence) {
        List<C> list = new ArrayList<>(sequence.getLength());
        for (C compound : sequence) {
            list.add(compound);
        }
        return list;
    }

    public static <C extends Compound> int indexOf(Sequence<C> sequence, C compound) {
        int index = 1;
        for (C currentCompound : sequence) {
            if (currentCompound.equals(compound)) {
                return index;
            }
            index++;
        }
        return 0;
    }

    public static <C extends Compound> int lastIndexOf(Sequence<C> sequence, C compound) {
        int index = indexOf(new ReversedSequenceView<>(sequence), compound);
        return (sequence.getLength() - index) + 1;
    }

    public static <C extends Compound> Iterator<C> createIterator(Sequence<C> sequence) {
        return new SequenceIterator<>(sequence);
    }

    public static <C extends Compound> SequenceView<C> createSubSequence(
            Sequence<C> sequence, int start, int end) {
        return new SequenceProxyView<>(sequence, start, end);
    }

    public static <C extends Compound> Sequence<C> shuffle(Sequence<C> sequence) {
        List<C> compounds = new ArrayList<>(sequence.getAsList());
        Collections.shuffle(compounds);
        return new ArrayListSequenceReader<>(compounds, sequence.getCompoundSet());
    }

    public static <C extends Compound> String checksum(Sequence<C> sequence) {
        CRC64Checksum checksum = new CRC64Checksum();
        for (C compound : sequence) {
            checksum.update(compound.getShortName());
        }
        return checksum.toString();
    }

    public static <C extends Compound> List<SequenceView<C>> nonOverlappingKmers(Sequence<C> sequence, int kmer) {
        List<SequenceView<C>> l = new ArrayList<>();
        Iterable<SequenceView<C>> w = new WindowedSequence<>(sequence, kmer);
        for (SequenceView<C> view : w) {
            l.add(view);
        }
        return l;
    }

    public static <C extends Compound> List<SequenceView<C>> overlappingKmers(Sequence<C> sequence, int kmer) {
        List<SequenceView<C>> l = new ArrayList<>();
        List<Iterator<SequenceView<C>>> windows = new ArrayList<>();

        for (int i = 1; i <= kmer; i++) {
            if (i == 1) {
                windows.add(new WindowedSequence<>(sequence, kmer).iterator());
            } else {
                SequenceView<C> sv = sequence.getSubSequence(i, sequence.getLength());
                windows.add(new WindowedSequence<>(sv, kmer).iterator());
            }
        }

        OUTER:
        while (true) {
            for (Iterator<SequenceView<C>> iterator : windows) {
                if (iterator.hasNext()) {
                    l.add(iterator.next());
                } else {
                    break OUTER;
                }
            }
        }
        return l;
    }

    @SuppressWarnings({"unchecked"})
    public static <C extends Compound> SequenceView<C> inverse(Sequence<C> sequence) {
        SequenceView<C> reverse = new ReversedSequenceView<>(sequence);
        if (sequence.getCompoundSet().isComplementable()) {
            return new ComplementSequenceView(reverse);
        }
        return reverse;
    }

    public static <C extends Compound> boolean sequenceEqualityIgnoreCase(Sequence<C> source, Sequence<C> target) {
        return baseSequenceEquality(source, target, true);
    }

    public static <C extends Compound> boolean sequenceEquality(Sequence<C> source, Sequence<C> target) {
        return baseSequenceEquality(source, target, false);
    }

    private static <C extends Compound> boolean baseSequenceEquality(Sequence<C> source, Sequence<C> target, boolean ignoreCase) {
        if (source.getLength() != target.getLength() ||
                !source.getCompoundSet().equals(target.getCompoundSet())) {
            return false;
        }

        Iterator<C> sIter = source.iterator();
        Iterator<C> tIter = target.iterator();
        while (sIter.hasNext()) {
            C s = sIter.next();
            C t = tIter.next();
            boolean cEqual = ignoreCase ? s.equalsIgnoreCase(t) : s.equals(t);
            if (!cEqual) {
                return false;
            }
        }
        return true;
    }

    public static class SequenceIterator<C extends Compound>
            implements Iterator<C> {

        private final Sequence<C> sequence;
        private final int length;
        private int currentPosition = 0;

        public SequenceIterator(Sequence<C> sequence) {
            this.sequence = sequence;
            this.length = sequence.getLength();
        }

        @Override
        public boolean hasNext() {
            return (currentPosition < length);
        }

        @Override
        public C next() {
            if(!hasNext()) {
                throw new NoSuchElementException("Exhausted sequence of elements");
            }
            return sequence.getCompoundAt(++currentPosition);
        }

        @Override
        public void remove() {
            throw new UnsupportedOperationException("Cannot remove() on a SequenceIterator");
        }
    }
}
