package org.biojava.nbio.core.sequence.compound;

import java.io.Serializable;
import org.biojava.nbio.core.sequence.template.AbstractCompound;
import org.biojava.nbio.core.sequence.template.Compound;
import org.biojava.nbio.core.sequence.template.CompoundSet;

public class AminoAcidCompound extends AbstractCompound implements Serializable {

    private static final long serialVersionUID = -1955116496725902319L;
    private final AminoAcidCompoundSet compoundSet;
    private final String shortName;
    private final String longName;
    private final int cachedHashCode;

    public AminoAcidCompound(AminoAcidCompoundSet compoundSet, String shortName, String longName, String description, Float molecularWeight) {
        super(shortName);
        this.shortName = shortName != null ? shortName.intern() : null;
        this.longName = longName != null ? longName.intern() : null;
        setShortName(this.shortName);
        setLongName(this.longName);
        setDescription(description);
        setMolecularWeight(molecularWeight);
        this.compoundSet = compoundSet;
        
        this.cachedHashCode = computeHashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        AminoAcidCompound that = (AminoAcidCompound) obj;
        return shortName.equals(that.getShortName()) &&
               longName.equals(that.getLongName());
    }

    @Override
    public int hashCode() {
        return cachedHashCode;
    }

    private int computeHashCode() {
        int result = shortName != null ? shortName.hashCode() : 0;
        result = 31 * result + (longName != null ? longName.hashCode() : 0);
        return result;
    }

    @Override
    public boolean equalsIgnoreCase(Compound compound) {
        if (this == compound) {
            return true;
        }
        if (compound == null || getClass() != compound.getClass()) {
            return false;
        }
        AminoAcidCompound that = (AminoAcidCompound) compound;
        return shortName.equalsIgnoreCase(that.getShortName()) &&
               longName.equalsIgnoreCase(that.getLongName());
    }

    public CompoundSet<AminoAcidCompound> getCompoundSet() {
        return compoundSet;
    }

    public String getShortName() {
        return shortName;
    }

    public String getLongName() {
        return longName;
    }
}