package org.biojava.nbio.core.sequence.compound;

import org.biojava.nbio.core.sequence.template.CompoundSet;
import org.biojava.nbio.core.sequence.template.Sequence;

import java.io.Serializable;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class AminoAcidCompoundSet implements CompoundSet<AminoAcidCompound>, Serializable {

    private static final long serialVersionUID = 4000344194364133456L;
    private final Map<String, AminoAcidCompound> aminoAcidCompoundCache = new HashMap<>();
    private final Map<String, AminoAcidCompound> aminoAcidCompoundCache3Letter = new HashMap<>();
    private final Map<AminoAcidCompound, Set<AminoAcidCompound>> equivalentsCache = new ConcurrentHashMap<>();
    private volatile boolean cacheInitialized = false;

    public AminoAcidCompoundSet() {
        populateCache();
        initializeThreeLetterCache();
    }

    private void populateCache() {
        aminoAcidCompoundCache.put("A", new AminoAcidCompound(this, "A", "Ala", "Alanine", 71.0788f));
        aminoAcidCompoundCache.put("R", new AminoAcidCompound(this, "R", "Arg", "Arginine", 156.1875f));
        aminoAcidCompoundCache.put("N", new AminoAcidCompound(this, "N", "Asn", "Asparagine", 114.1039f));
        aminoAcidCompoundCache.put("D", new AminoAcidCompound(this, "D", "Asp", "Aspartic acid", 115.0886f));
        aminoAcidCompoundCache.put("C", new AminoAcidCompound(this, "C", "Cys", "Cysteine", 103.1388f));
        aminoAcidCompoundCache.put("E", new AminoAcidCompound(this, "E", "Glu", "Glutamic acid", 129.1155f));
        aminoAcidCompoundCache.put("Q", new AminoAcidCompound(this, "Q", "Gln", "Glutamine", 128.1307f));
        aminoAcidCompoundCache.put("G", new AminoAcidCompound(this, "G", "Gly", "Glycine", 57.0519f));
        aminoAcidCompoundCache.put("H", new AminoAcidCompound(this, "H", "His", "Histidine", 137.1411f));
        aminoAcidCompoundCache.put("I", new AminoAcidCompound(this, "I", "Ile", "Isoleucine", 113.1594f));
        aminoAcidCompoundCache.put("L", new AminoAcidCompound(this, "L", "Leu", "Leucine", 113.1594f));
        aminoAcidCompoundCache.put("K", new AminoAcidCompound(this, "K", "Lys", "Lysine", 128.1741f));
        aminoAcidCompoundCache.put("M", new AminoAcidCompound(this, "M", "Met", "Methionine", 131.1986f));
        aminoAcidCompoundCache.put("F", new AminoAcidCompound(this, "F", "Phe", "Phenylalanine", 147.1766f));
        aminoAcidCompoundCache.put("P", new AminoAcidCompound(this, "P", "Pro", "Proline", 97.1167f));
        aminoAcidCompoundCache.put("S", new AminoAcidCompound(this, "S", "Ser", "Serine", 87.0782f));
        aminoAcidCompoundCache.put("T", new AminoAcidCompound(this, "T", "Thr", "Threonine", 101.1051f));
        aminoAcidCompoundCache.put("W", new AminoAcidCompound(this, "W", "Trp", "Tryptophan", 186.2132f));
        aminoAcidCompoundCache.put("Y", new AminoAcidCompound(this, "Y", "Tyr", "Tyrosine", 163.1760f));
        aminoAcidCompoundCache.put("V", new AminoAcidCompound(this, "V", "Val", "Valine", 99.1326f));
        aminoAcidCompoundCache.put("B", new AminoAcidCompound(this, "B", "Asx", "Asparagine or Aspartic acid", null));
        aminoAcidCompoundCache.put("Z", new AminoAcidCompound(this, "Z", "Glx", "Glutamine or Glutamic acid", null));
        aminoAcidCompoundCache.put("J", new AminoAcidCompound(this, "J", "Xle", "Leucine or Isoleucine", null));
        aminoAcidCompoundCache.put("X", new AminoAcidCompound(this, "X", "Xaa", "Unspecified", null));
        aminoAcidCompoundCache.put("-", new AminoAcidCompound(this, "-", "---", "Unspecified", null));
        aminoAcidCompoundCache.put(".", new AminoAcidCompound(this, ".", "...", "Unspecified", null));
        aminoAcidCompoundCache.put("_", new AminoAcidCompound(this, "_", "___", "Unspecified", null));
        aminoAcidCompoundCache.put("*", new AminoAcidCompound(this, "*", "***","Stop",null));
        aminoAcidCompoundCache.put("U", new AminoAcidCompound(this, "U", "Sec", "Selenocysteine", 150.0388f));
        aminoAcidCompoundCache.put("O", new AminoAcidCompound(this, "O", "Pyl", "Pyrrolysine", 255.3172f));
    }

    private void initializeThreeLetterCache() {
        for (Map.Entry<String, AminoAcidCompound> entry : aminoAcidCompoundCache.entrySet()) {
            AminoAcidCompound aa = entry.getValue();
            aminoAcidCompoundCache3Letter.put(aa.getLongName().toUpperCase(), aa);
        }
    }

    @Override
    public String getStringForCompound(AminoAcidCompound compound) {
        return compound.toString();
    }

    @Override
    public AminoAcidCompound getCompoundForString(String string) {
        if (string.length() == 0) {
            return null;
        }
        if (string.length() == 3) {
            return this.aminoAcidCompoundCache3Letter.get(string.toUpperCase());
        }
        if (string.length() > this.getMaxSingleCompoundStringLength()) {
            throw new IllegalArgumentException("String supplied (" + string + ") is too long. Max is " + getMaxSingleCompoundStringLength());
        }
        return this.aminoAcidCompoundCache.get(string.toUpperCase());
    }

    @Override
    public int getMaxSingleCompoundStringLength() {
        return 1;
    }

    @Override
    public boolean isCompoundStringLengthEqual() {
        return true;
    }

    private static final AminoAcidCompoundSet aminoAcidCompoundSet = new AminoAcidCompoundSet();

    public static AminoAcidCompoundSet getAminoAcidCompoundSet() {
        return aminoAcidCompoundSet;
    }

    @Override
    public boolean compoundsEquivalent(AminoAcidCompound compoundOne, AminoAcidCompound compoundTwo) {
        Set<AminoAcidCompound> equivalents = getEquivalentCompounds(compoundOne);
        return (equivalents != null) && equivalents.contains(compoundTwo);
    }

    @Override
    public Set<AminoAcidCompound> getEquivalentCompounds(AminoAcidCompound compound) {
        if (!cacheInitialized) {
            synchronized (this) {
                if (!cacheInitialized) {
                    initializeEquivalentsCache();
                    cacheInitialized = true;
                }
            }
        }
        return equivalentsCache.get(compound);
    }

    private void initializeEquivalentsCache() {
        for (AminoAcidCompound c : aminoAcidCompoundCache.values()) {
            equivalentsCache.put(c, Collections.singleton(c));
        }
        addAmbiguousEquivalents("N", "D", "B");
        addAmbiguousEquivalents("E", "Q", "Z");
        addAmbiguousEquivalents("I", "L", "J");
        setUpGapEquivalence();
    }

    private void addAmbiguousEquivalents(String one, String two, String either) {
        AminoAcidCompound cOne = aminoAcidCompoundCache.get(one);
        AminoAcidCompound cTwo = aminoAcidCompoundCache.get(two);
        AminoAcidCompound cEither = aminoAcidCompoundCache.get(either);
        Set<AminoAcidCompound> equivalents = new HashSet<>(Arrays.asList(cOne, cTwo, cEither));
        equivalentsCache.put(cEither, equivalents);
        equivalentsCache.put(cOne, new HashSet<>(Arrays.asList(cOne, cEither)));
        equivalentsCache.put(cTwo, new HashSet<>(Arrays.asList(cTwo, cEither)));
    }

    private void setUpGapEquivalence() {
        AminoAcidCompound gap1 = aminoAcidCompoundCache.get("-");
        AminoAcidCompound gap2 = aminoAcidCompoundCache.get(".");
        AminoAcidCompound gap3 = aminoAcidCompoundCache.get("_");
        Set<AminoAcidCompound> gaps = new HashSet<>(Arrays.asList(gap1, gap2, gap3));
        equivalentsCache.put(gap1, gaps);
        equivalentsCache.put(gap2, gaps);
        equivalentsCache.put(gap3, gaps);
    }

    @Override
    public boolean hasCompound(AminoAcidCompound compound) {
        return aminoAcidCompoundCache.containsValue(compound);
    }

    @Override
    public boolean isValidSequence(Sequence<AminoAcidCompound> sequence) {
        for (AminoAcidCompound compound : sequence) {
            if (!hasCompound(compound)) {
                return false;
            }
        }
        return true;
    }

    @Override
    public List<AminoAcidCompound> getAllCompounds() {
        return new ArrayList<>(aminoAcidCompoundCache.values());
    }

    @Override
    public boolean isComplementable() {
        return false;
    }
}
