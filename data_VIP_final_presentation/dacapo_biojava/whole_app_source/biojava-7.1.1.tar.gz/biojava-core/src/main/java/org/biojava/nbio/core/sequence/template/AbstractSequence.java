package org.biojava.nbio.core.sequence.template;

import org.biojava.nbio.core.exceptions.CompoundNotFoundException;
import org.biojava.nbio.core.sequence.AccessionID;
import org.biojava.nbio.core.sequence.DataSource;
import org.biojava.nbio.core.sequence.Strand;
import org.biojava.nbio.core.sequence.TaxonomyID;
import org.biojava.nbio.core.sequence.features.*;
import org.biojava.nbio.core.sequence.loader.UniprotProxySequenceReader;
import org.biojava.nbio.core.sequence.location.SequenceLocation;
import org.biojava.nbio.core.sequence.location.SimpleLocation;
import org.biojava.nbio.core.sequence.location.template.Location;
import org.biojava.nbio.core.sequence.reference.AbstractReference;
import org.biojava.nbio.core.sequence.storage.ArrayListSequenceReader;
import org.biojava.nbio.core.util.Equals;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

public abstract class AbstractSequence<C extends Compound> implements Sequence<C> {

    private final static Logger logger = LoggerFactory.getLogger(AbstractSequence.class);

    private TaxonomyID taxonomy;
    private AccessionID accession;
    private SequenceReader<C> sequenceStorage = null;
    private CompoundSet<C> compoundSet;
    private AnnotationType annotationType = AnnotationType.UNKNOWN;
    private String description;
    private String originalHeader;
    private Collection<Object> userCollection;
    private Integer bioBegin = null;
    private Integer bioEnd = null;
    private AbstractSequence<?> parentSequence = null;
    private String source = null;
    private ArrayList<String> notesList = new ArrayList<>(); 
    private Double sequenceScore = null;
    private FeaturesKeyWordInterface featuresKeyWord = null;
    private DatabaseReferenceInterface databaseReferences = null;
    private FeatureRetriever featureRetriever = null;
    private List<FeatureInterface<AbstractSequence<C>, C>> features = new ArrayList<>();
    private Map<String, List<FeatureInterface<AbstractSequence<C>, C>>> groupedFeatures = new LinkedHashMap<>();
    private List<String> comments = new ArrayList<>();
    private List<AbstractReference> references;

    public AbstractSequence() {
    }

    public AbstractSequence(String seqString, CompoundSet<C> compoundSet) throws CompoundNotFoundException {
        setCompoundSet(compoundSet);
        initSequenceStorage(seqString);
    }

    protected void initSequenceStorage(String seqString) throws CompoundNotFoundException {
        sequenceStorage = new ArrayListSequenceReader<>();
        sequenceStorage.setCompoundSet(this.getCompoundSet());
        sequenceStorage.setContents(seqString);
    }

    public AbstractSequence(SequenceReader<C> proxyLoader, CompoundSet<C> compoundSet) {
        setCompoundSet(compoundSet);
        setProxySequenceReader(proxyLoader);
    }

    public void setProxySequenceReader(SequenceReader<C> proxyLoader) {
        this.sequenceStorage = proxyLoader;
        if (proxyLoader instanceof FeaturesKeyWordInterface) {
            this.setFeaturesKeyWord((FeaturesKeyWordInterface) sequenceStorage);
        }
        if (proxyLoader instanceof DatabaseReferenceInterface) {
            this.setDatabaseReferences((DatabaseReferenceInterface) sequenceStorage);
        }

        if (proxyLoader instanceof FeatureRetriever) {
            this.setFeatureRetriever((FeatureRetriever) sequenceStorage);
            Map<String, List<AbstractFeature<AbstractSequence<C>, C>>> featureMap = getFeatureRetriever().getFeatures();
            featureMap.forEach((key, featureList) -> featureList.forEach(this::addFeature));

            DBReferenceInfo dbQualifier = (DBReferenceInfo) featureMap.getOrDefault("source", Collections.emptyList()).stream()
                        .filter(f -> f.getQualifiers().containsKey("db_xref"))
                        .flatMap(f -> ((ArrayList) f.getQualifiers().get("db_xref")).stream())
                        .findFirst().orElse(null);

            if (dbQualifier != null) {
                this.setTaxonomy(new TaxonomyID(dbQualifier.getDatabase() + ":" + dbQualifier.getId(), DataSource.UNKNOWN));
            }
        }

        if (getAccession() == null && proxyLoader instanceof UniprotProxySequenceReader) {
            this.setAccession(proxyLoader.getAccession());
        }
    }

    public SequenceReader<C> getProxySequenceReader() {
        return sequenceStorage;
    }

    public Integer getBioBegin() {
        return bioBegin == null ? 1 : bioBegin;
    }

    public void setBioBegin(Integer bioBegin) {
        this.bioBegin = bioBegin;
    }

    public Integer getBioEnd() {
        return bioEnd == null ? this.getLength() : bioEnd;
    }

    public void setBioEnd(Integer bioEnd) {
        this.bioEnd = bioEnd;
    }

    public Collection<Object> getUserCollection() {
        return userCollection;
    }

    public void setUserCollection(Collection<Object> userCollection) {
        this.userCollection = userCollection;
    }

    public AnnotationType getAnnotationType() {
        return annotationType;
    }

    public void setAnnotationType(AnnotationType annotationType) {
        this.annotationType = annotationType;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getOriginalHeader() {
        return originalHeader;
    }

    public void setOriginalHeader(String originalHeader) {
        this.originalHeader = originalHeader;
    }

    public AbstractSequence<?> getParentSequence() {
        return parentSequence;
    }

    public void setParentSequence(AbstractSequence<?> parentSequence) {
        this.parentSequence = parentSequence;
    }

    public String getSource() {
        if (source != null) {
            return source;
        }
        if (parentSequence != null) {
            return parentSequence.getSource();
        }
        return null;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public void addNote(String note) {
        notesList.add(note);
    }

    public void removeNote(String note) {
        notesList.remove(note);
    }

    public ArrayList<String> getNotesList() { 
        return notesList;
    }

    public void setNotesList(ArrayList<String> notesList) { 
        this.notesList = notesList;
    }

    public Double getSequenceScore() {
        return sequenceScore;
    }

    public void setSequenceScore(Double sequenceScore) {
        this.sequenceScore = sequenceScore;
    }

    public List<AbstractReference> getReferences() {
        return references;
    }

    public void setReferences(List<AbstractReference> references) {
        this.references = references;
    }

    public List<FeatureInterface<AbstractSequence<C>, C>> getFeatures(String featureType, int bioSequencePosition) {
        List<FeatureInterface<AbstractSequence<C>, C>> featureHits = new ArrayList<>();
        List<FeatureInterface<AbstractSequence<C>, C>> featuresByType = getFeaturesByType(featureType);
        featuresByType.stream()
                    .filter(feature -> bioSequencePosition >= feature.getLocations().getStart().getPosition() &&
                                bioSequencePosition <= feature.getLocations().getEnd().getPosition())
                    .forEach(featureHits::add);
        return featureHits;
    }

    public List<FeatureInterface<AbstractSequence<C>, C>> getFeatures(int bioSequencePosition) {
        List<FeatureInterface<AbstractSequence<C>, C>> featureHits = new ArrayList<>();
        features.stream()
                .filter(feature -> bioSequencePosition >= feature.getLocations().getStart().getPosition() &&
                            bioSequencePosition <= feature.getLocations().getEnd().getPosition())
                .forEach(featureHits::add);
        return featureHits;
    }

    public List<FeatureInterface<AbstractSequence<C>, C>> getFeatures() {
        return features;
    }

    public void addFeature(int bioStart, int bioEnd, FeatureInterface<AbstractSequence<C>, C> feature) {
        SequenceLocation<AbstractSequence<C>, C> sequenceLocation =
                new SequenceLocation<>(bioStart, bioEnd, this);
        feature.setLocation(sequenceLocation);
        addFeature(feature);
    }

    public void addFeature(FeatureInterface<AbstractSequence<C>, C> feature) {
        features.add(feature);
        groupedFeatures.computeIfAbsent(feature.getType(), k -> new ArrayList<>()).add(feature);
        Collections.sort(features, AbstractFeature.LOCATION_LENGTH);
        List<FeatureInterface<AbstractSequence<C>, C>> featureList = groupedFeatures.get(feature.getType());
        Collections.sort(featureList, AbstractFeature.LOCATION_LENGTH);
    }

    public void removeFeature(FeatureInterface<AbstractSequence<C>, C> feature) {
        features.remove(feature);
        List<FeatureInterface<AbstractSequence<C>, C>> featureList = groupedFeatures.get(feature.getType());
        if (featureList != null) {
            featureList.remove(feature);
            if (featureList.isEmpty()) {
                groupedFeatures.remove(feature.getType());
            }
        }
    }

    public List<FeatureInterface<AbstractSequence<C>, C>> getFeaturesByType(String type) {
        return groupedFeatures.getOrDefault(type, new ArrayList<>());
    }

    public List<String> getComments() {
        return comments;
    }

    public void setComments(List<String> comments) {
        this.comments = comments;
    }

    public FeaturesKeyWordInterface getFeaturesKeyWord() {
        return featuresKeyWord;
    }

    public void setFeaturesKeyWord(FeaturesKeyWordInterface featuresKeyWord) {
        this.featuresKeyWord = featuresKeyWord;
    }

    public DatabaseReferenceInterface getDatabaseReferences() {
        return databaseReferences;
    }

    public void setDatabaseReferences(DatabaseReferenceInterface databaseReferences) {
        this.databaseReferences = databaseReferences;
    }

    public FeatureRetriever getFeatureRetriever() {
        return featureRetriever;
    }

    public void setFeatureRetriever(FeatureRetriever featureRetriever) {
        this.featureRetriever = featureRetriever;
    }

    public enum AnnotationType {
        CURATED, PREDICTED, UNKNOWN;
    }

    @Override
    public AccessionID getAccession() {
        return accession;
    }

    public void setAccession(AccessionID accession) {
        this.accession = accession;
    }

    public TaxonomyID getTaxonomy() {
        return taxonomy;
    }

    public void setTaxonomy(TaxonomyID taxonomy) {
        this.taxonomy = taxonomy;
    }

    @Override
    public CompoundSet<C> getCompoundSet() {
        return compoundSet;
    }

    public void setCompoundSet(CompoundSet<C> compoundSet) {
        this.compoundSet = compoundSet;
    }

    @Override
    public boolean equals(Object o){

        if(! Equals.classEqual(this, o)) {
            return false;
        }

        Sequence<C> other = (Sequence<C>)o;

        if ( other.getCompoundSet() != getCompoundSet())
            return false;

        List<C> rawCompounds = getAsList();
        List<C> otherCompounds = other.getAsList();

        if ( rawCompounds.size() != otherCompounds.size())
            return false;

        for (int i = 0 ; i < rawCompounds.size() ; i++){
            Compound myCompound = rawCompounds.get(i);
            Compound otherCompound = otherCompounds.get(i);
            if ( ! myCompound.equalsIgnoreCase(otherCompound))
                return false;
        }
        return true;
    }

    @Override
    public int hashCode(){
        String s = getSequenceAsString();
        return s.hashCode();
    }

    @Override
    public String toString() {
        return getSequenceAsString();
    }

    private SequenceReader<C> getSequenceStorage() {
        if (sequenceStorage != null) {
            return sequenceStorage;
        }
        if (parentSequence != null) {
            if ( this.compoundSet.equals(parentSequence.getCompoundSet())){
                sequenceStorage = new ArrayListSequenceReader<>();
                sequenceStorage.setCompoundSet(this.getCompoundSet());
                try {
                    sequenceStorage.setContents(parentSequence.getSequenceAsString());
                } catch (CompoundNotFoundException e) {
                    logger.error("Problem setting contents from parent sequence, some unrecognised compound: {}",e.getMessage());
                }
                return sequenceStorage;
            }
        }
        return null;
    }

    public String getSequenceAsString(Integer bioStart, Integer bioEnd, Strand strand) {
        Location loc = new SimpleLocation(bioStart, bioEnd, strand);
        return loc.getSubSequence(this).getSequenceAsString();
    }

    @Override
    public String getSequenceAsString() {
        return SequenceMixin.toString(this);

    }

    @Override
    public List<C> getAsList() {
        return sequenceStorage.getAsList();
    }

    @Override
    public C getCompoundAt(int position) {
        return getSequenceStorage().getCompoundAt(position);
    }

    @Override
    public int getIndexOf(C compound) {
        return getSequenceStorage().getIndexOf(compound);
    }

    @Override
    public int getLastIndexOf(C compound) {
        return getSequenceStorage().getLastIndexOf(compound);
    }

    @Override
    public int getLength() {
        return getSequenceStorage().getLength();
    }

    @Override
    public SequenceView<C> getSubSequence(final Integer bioStart, final Integer bioEnd) {
        return new SequenceProxyView<>(this, bioStart, bioEnd);
    }

    @Override
    public Iterator<C> iterator() {
        return getSequenceStorage().iterator();
    }

    @Override
    public int countCompounds(C... compounds) {
        return SequenceMixin.countCompounds(this, compounds);
    }

    @Override
    public SequenceView<C> getInverse() {
        return SequenceMixin.inverse(this);
    }

}
