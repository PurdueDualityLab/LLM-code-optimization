package org.biojava.nbio.aaproperties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Set;

public class Utils {

    private static final Logger logger = LoggerFactory.getLogger(Utils.class);

    public static double roundToDecimals(double d, int c) {
        if (c < 0) return d;
        double p = Math.pow(10, c);
        double tmp = Math.round(d * p);
        return tmp / p;
    }

    public static boolean doesSequenceContainInvalidChar(String sequence, Set<Character> cSet) {
        for (char c : sequence.toCharArray()) {
            if (!cSet.contains(c)) return true;
        }
        return false;
    }

    public static int getNumberOfInvalidChar(String sequence, Set<Character> cSet, boolean ignoreCase) {
        if (cSet == null) cSet = PeptideProperties.standardAASet;
        int total = 0;
        for (char c : sequence.toCharArray()) {
            if (ignoreCase) c = Character.toUpperCase(c);
            if (!cSet.contains(c)) total++;
        }
        return total;
    }

    public static String cleanSequence(String sequence, Set<Character> cSet) {
        if (cSet == null) cSet = PeptideProperties.standardAASet;
        StringBuilder cleanSeq = new StringBuilder(sequence.length());
        for (char c : sequence.toCharArray()) {
            cleanSeq.append(cSet.contains(c) ? c : '-');
        }
        return cleanSeq.toString();
    }

    public static String checkSequence(String sequence) {
        return checkSequence(sequence, null);
    }

    public static String checkSequence(String sequence, Set<Character> cSet) {
        if (cSet == null) cSet = PeptideProperties.standardAASet;
        boolean containInvalid = sequence != null && doesSequenceContainInvalidChar(sequence, cSet);
        return containInvalid ? cleanSequence(sequence, cSet) : sequence;
    }
}